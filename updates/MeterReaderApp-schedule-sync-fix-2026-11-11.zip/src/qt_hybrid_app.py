"""Qt Widgets + QML hybrid UI for the Water Meter Reader app."""

from __future__ import annotations

import sys
import os
import re
import subprocess
import threading
import time
import uuid
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

os.environ["QT_QUICK_CONTROLS_STYLE"] = "Basic"

try:
    from .billing_policy import payment_due_date
    from .reading_dates import previous_reading_date
    from .reader_identity import reader_display_name
    from .wifi import connected_wifi_ssid, connect_wifi_network, scan_wifi_networks, split_nmcli_fields
except ImportError:
    from billing_policy import payment_due_date
    from reading_dates import previous_reading_date
    from reader_identity import reader_display_name
    from wifi import connected_wifi_ssid, connect_wifi_network, scan_wifi_networks, split_nmcli_fields

try:
    from .qt_compat import (
        CPU_ARCH,
        QApplication,
        QFont,
        QMainWindow,
        QObject,
        Property,
        PYTHON_VERSION,
        QQuickWidget,
        QT_BINDING,
        QT_BINDING_VERSION,
        QT_VERSION,
        QStackedWidget,
        QTimer,
        Qt,
        QUrl,
        QVBoxLayout,
        QWidget,
        Signal,
        Slot,
    )
except ImportError:
    from qt_compat import (
        CPU_ARCH,
        QApplication,
        QFont,
        QMainWindow,
        QObject,
        Property,
        PYTHON_VERSION,
        QQuickWidget,
        QT_BINDING,
        QT_BINDING_VERSION,
        QT_VERSION,
        QStackedWidget,
        QTimer,
        Qt,
        QUrl,
        QVBoxLayout,
        QWidget,
        Signal,
        Slot,
    )

try:
    from .database import (
        authenticate_user,
        cache_meter_reader_credentials,
        clear_current_meter_reader,
        get_receipt_print_by_id,
        get_assigned_routes,
        get_schedule_payment_due_date,
        get_all_zone_names,
        get_app_setting,
        get_current_meter_reader,
        get_consumer_by_id,
        get_latest_receipt_print,
        list_receipt_print_history,
        list_receipt_print_months,
        get_zone_consumers_with_status,
        get_zone_stats,
        init_db,
        save_current_meter_reader,
        set_app_setting,
        save_receipt_print,
        update_consumer_due_date,
        replace_consumers_from_sync,
        replace_reading_schedules_from_sync,
        mark_route_cache_verified,
        save_reading,
        search_consumer,
        search_consumers_by_zone,
        sort_and_mark_nearby,
    )
except ImportError:
    from database import (
        authenticate_user,
        cache_meter_reader_credentials,
        clear_current_meter_reader,
        get_receipt_print_by_id,
        get_assigned_routes,
        get_schedule_payment_due_date,
        get_all_zone_names,
        get_app_setting,
        get_current_meter_reader,
        get_consumer_by_id,
        get_latest_receipt_print,
        list_receipt_print_history,
        list_receipt_print_months,
        get_zone_consumers_with_status,
        get_zone_stats,
        init_db,
        save_current_meter_reader,
        set_app_setting,
        save_receipt_print,
        update_consumer_due_date,
        replace_consumers_from_sync,
        replace_reading_schedules_from_sync,
        mark_route_cache_verified,
        save_reading,
        search_consumer,
        search_consumers_by_zone,
        sort_and_mark_nearby,
    )

try:
    from .handheld_sync import HandheldSyncDataAccess, SyncConfig, _build_bill_payload, format_sync_error
except ImportError:
    try:
        from handheld_sync import HandheldSyncDataAccess, SyncConfig, _build_bill_payload, format_sync_error
    except ImportError:
        HandheldSyncDataAccess = None
        SyncConfig = None

        def format_sync_error(stage: str, exc, endpoint: str = "", **_kwargs) -> str:
            return f"Stage: {stage}\nProblem: {exc}"

try:
    from .receipt import (
        apply_authoritative_bill,
        build_receipt_text,
        build_reprint_receipt_text,
        can_use_system_printer,
        manila_current_date,
        receipt_billing_reference as _receipt_billing_reference,
        print_test_receipt,
        send_to_system_printer,
    )
except ImportError:
    from receipt import (
        apply_authoritative_bill,
        build_receipt_text,
        build_reprint_receipt_text,
        can_use_system_printer,
        manila_current_date,
        receipt_billing_reference as _receipt_billing_reference,
        print_test_receipt,
        send_to_system_printer,
    )

QML_MAIN_FILE = Path(__file__).resolve().parent.parent / "assets" / "qml" / "MainContainer.qml"
QML_LOGIN_FILE = Path(__file__).resolve().parent.parent / "assets" / "qml" / "Login.qml"

print(f"Using Qt binding: {QT_BINDING}")
print(f"Python version: {PYTHON_VERSION}")
print(f"CPU architecture: {CPU_ARCH}")
print(f"Qt binding version: {QT_BINDING_VERSION}")
print(f"Qt version: {QT_VERSION}")
print(f"QML main file: {QML_MAIN_FILE}")


def _load_qml(quick: QQuickWidget, path: Path) -> None:
    """Load a QML view and turn otherwise-silent load failures into startup errors."""
    if not path.is_file():
        raise RuntimeError(f"QML file was not found: {path}")
    quick.setResizeMode(QQuickWidget.ResizeMode.SizeRootObjectToView)
    quick.setSource(QUrl.fromLocalFile(str(path)))
    if quick.status() == QQuickWidget.Status.Error:
        details = "\n".join(error.toString() for error in quick.errors())
        raise RuntimeError(f"Unable to load the device UI from {path}:\n{details}")


def _to_float(value, default: float = 0.0) -> float:
    if value in (None, ""):
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _display_consumer_context(sync_dal, consumer_id: int) -> dict:
    """Display the synchronized SQLite snapshot without a per-screen fetch."""
    getter = getattr(sync_dal, "getCachedConsumerContext", None)
    if getter is None:
        getter = sync_dal.getConsumerContext
    return getter(int(consumer_id))


def _use_local_bill_for_display(server_bill: dict | None, local_bill: dict) -> bool:
    if not server_bill:
        return True
    if str(server_bill.get("status") or "").strip().lower() == "paid":
        return False
    server_due = _to_float(server_bill.get("amount_due", server_bill.get("total_amount")))
    server_after = _to_float(
        server_bill.get("total_after_due_date", server_bill.get("amount_after_due_date"))
    )
    return (
        server_due <= 0 < _to_float(local_bill.get("amount_due"))
        or server_after <= 0 < _to_float(local_bill.get("total_after_due_date"))
        or (not server_bill.get("due_date") and bool(local_bill.get("due_date")))
        or (_to_float(server_bill.get("water_charge", server_bill.get("class_cost"))) <= 0
            < _to_float(local_bill.get("water_charge")))
    )


def _has_valid_bill_coverage(bill: dict | None) -> bool:
    """Validate the saved coverage on one bill without borrowing other dates."""
    if not bill:
        return False
    start = _normalize_iso_date(bill.get("date_covered_from"))
    end = _normalize_iso_date(bill.get("date_covered_to"))
    return bool(start and end and start <= end)


def _cached_bill_for_reading(context: dict, reading: dict) -> dict | None:
    """Use the server bill when complete, otherwise the matching local calculation."""
    reading_day = _normalize_iso_date(reading.get("reading_date"))
    local = context.get("local_bill") if isinstance(context.get("local_bill"), dict) else {}
    server = context.get("bill") if isinstance(context.get("bill"), dict) else context

    def matches(bill: dict) -> bool:
        return bool(
            re.fullmatch(r"SLR[0-9]{10}", str(bill.get("billing_reference") or "")) and bill.get("due_date")
            and _normalize_iso_date(bill.get("bill_date")) == reading_day
            and (not bill.get("schedule_id") or not reading.get("schedule_id")
                 or str(bill["schedule_id"]) == str(reading["schedule_id"]))
        )

    if matches(local) and (not matches(server) or _use_local_bill_for_display(server, local)):
        selected = local
    else:
        selected = server if matches(server) else None
    return selected if _has_valid_bill_coverage(selected) else None


def _format_reading(value) -> str:
    numeric = _to_float(value, 0.0)
    text = f"{numeric:.2f}"
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text


def _normalize_iso_date(value) -> str | None:
    if value in (None, ""):
        return None
    raw = str(value).strip()
    if not raw:
        return None
    raw = raw.split("T", 1)[0].split(" ", 1)[0]
    try:
        return datetime.fromisoformat(raw).date().isoformat()
    except ValueError:
        return None


def _add_months(value: datetime, months: int) -> datetime:
    month_index = value.month - 1 + months
    year = value.year + month_index // 12
    month = month_index % 12 + 1
    next_month = datetime(year + 1, 1, 1) if month == 12 else datetime(year, month + 1, 1)
    last_day = (next_month - timedelta(days=1)).day
    return value.replace(year=year, month=month, day=min(value.day, last_day))


def _month_window(value: datetime.date) -> tuple[str, str]:
    start = value.replace(day=1)
    if start.month == 12:
        next_month = start.replace(year=start.year + 1, month=1, day=1)
    else:
        next_month = start.replace(month=start.month + 1, day=1)
    end = next_month - timedelta(days=1)
    return start.isoformat(), end.isoformat()


def _multi_day_assignment_window(value: datetime.date) -> tuple[str, str]:
    current_start = value.replace(day=1)
    # Keep a full year of missed routes discoverable while caching two months ahead.
    previous_start = current_start.replace(year=current_start.year - 1)
    if current_start.month >= 11:
        end_month = current_start.replace(year=current_start.year + 1, month=(current_start.month + 2) % 12 or 12, day=1)
    else:
        end_month = current_start.replace(month=current_start.month + 2, day=1)
    end = end_month - timedelta(days=1)
    return previous_start.isoformat(), end.isoformat()


def _assignment_download_window() -> tuple[str, str]:
    today = manila_current_date()
    _, end = _multi_day_assignment_window(today)
    return today.isoformat(), end


def _mirror_assigned_consumer_rows(sync_dal, consumers: list[dict]) -> tuple[int, dict]:
    report: dict = {}
    mirrored = replace_consumers_from_sync(consumers, report=report)
    if report["skipped"]:
        sync_dal._audit(None, "failed", "Assignment rows skipped while updating the device cache", report)
    return mirrored, report


def _summarize_assignment_download(consumers: list[dict], mirror_report: dict | None = None) -> str:
    consumer_ids: set[str] = set()
    schedule_ids: set[str] = set()
    assignments: set[tuple[str, str]] = set()
    repeated = 0
    for row in consumers:
        consumer_id = str(row.get("id") or row.get("consumer_id") or "").strip()
        schedule_id = str(row.get("schedule_id") or row.get("Schedule_ID") or "").strip()
        if consumer_id:
            consumer_ids.add(consumer_id)
        if consumer_id and schedule_id:
            schedule_ids.add(schedule_id)
            key = (consumer_id, schedule_id)
            if key in assignments:
                repeated += 1
            assignments.add(key)
    summary = (
        f"Unique consumers: {len(consumer_ids)} | Schedules: {len(schedule_ids)} | "
        f"Repeated assignment rows: {repeated}"
    )
    if mirror_report is not None:
        summary += f"\nSkipped rows: {mirror_report.get('skipped', 0)}"
        reasons = mirror_report.get("skip_reasons") or {}
        if reasons:
            summary += " | " + " | ".join(f"{reason}: {count}" for reason, count in reasons.items())
            summary += "\nCheck meter assignments in the main system for the skipped records."
    return summary


def _billing_month_date(value, fallback: str = "") -> str:
    raw = str(value or "").strip()
    if raw:
        for fmt in ("%Y-%m", "%B %Y", "%b %Y", "%Y-%m-%d"):
            try:
                return datetime.strptime(raw, fmt).date().replace(day=1).isoformat()
            except ValueError:
                continue
    return _normalize_iso_date(fallback) or ""


def _route_reading_date(
    billing_date: str,
    start_date: str = "",
    due_date: str = "",
    today: datetime.date | None = None,
) -> datetime.date | None:
    """Choose a persisted reading date inside the route's billing month/window."""
    normalized_month = _normalize_iso_date(billing_date)
    if not normalized_month:
        return None
    month_anchor = datetime.fromisoformat(normalized_month).date().replace(day=1)
    reference = today or datetime.now().date()
    if month_anchor.month == 12:
        next_month = month_anchor.replace(year=month_anchor.year + 1, month=1)
    else:
        next_month = month_anchor.replace(month=month_anchor.month + 1)
    last_day = (next_month - timedelta(days=1)).day
    reading_date = month_anchor.replace(day=min(reference.day, last_day))
    normalized_start = _normalize_iso_date(start_date)
    normalized_due = _normalize_iso_date(due_date)
    if normalized_start:
        reading_date = max(reading_date, datetime.fromisoformat(normalized_start).date())
    if normalized_due:
        reading_date = min(reading_date, datetime.fromisoformat(normalized_due).date())
    return reading_date


def _group_route_rows(routes: list[dict], today: datetime.date | None = None) -> list[dict]:
    """Show current and upcoming work without expired assignments or carry-over."""
    grouped: dict[tuple[str, str, str, str], dict] = {}
    reference_text = (today or manila_current_date()).isoformat()
    for row in routes or []:
        deadline = str(row.get("due_date") or row.get("start_date") or "")[:10]
        if (deadline and deadline < reference_text) or str(row.get("status") or "").strip().lower() in {"overdue", "cancelled"}:
            continue
        meter_reader_id = str(row.get("meter_reader_id") or "")
        start_date = str(row.get("start_date") or "")
        due_date = str(row.get("due_date") or start_date)
        billing_month = str(row.get("billing_month") or "")
        key = (meter_reader_id, start_date, due_date, billing_month)
        group = grouped.setdefault(
            key,
            {
                "scheduleId": "route|" + "|".join(key),
                "meterReaderId": meter_reader_id,
                "startDate": start_date,
                "dueDate": due_date,
                "paymentDueDate": str(row.get("schedule_payment_due_date") or ""),
                "billingMonth": billing_month,
                "billingDate": _billing_month_date(billing_month, start_date),
                "schedules": [],
            },
        )
        group["schedules"].append(
            {
                "scheduleId": str(row.get("schedule_id") or ""),
                "zoneName": str(row.get("zone_name") or ""),
                "status": str(row.get("display_status") or row.get("status") or "Scheduled"),
                "offlineReady": bool(row.get("cache_verified_at")) and int(row.get("cached_consumer_count") or 0) > 0,
                "startDate": start_date,
                "dueDate": due_date,
                "paymentDueDate": str(row.get("schedule_payment_due_date") or ""),
                "billingMonth": billing_month,
                "unreadCount": int(row.get("unread_count") or 0),
                "isCarryOver": False,
            }
        )

    status_rank = {"Overdue": 0, "In Progress": 1, "Scheduled": 2, "Completed": 3}
    result = []
    for group in grouped.values():
        schedules = sorted(group["schedules"], key=lambda item: _natural_display_key(item.get("zoneName")))
        group["schedules"] = schedules
        group["viewSchedules"] = list(schedules)
        group["zones"] = ["All zones"] + list(dict.fromkeys(
            item["zoneName"] for item in schedules if item.get("zoneName")
        ))
        group["zoneName"] = "All zones"
        group["offlineReady"] = bool(schedules) and all(item.get("offlineReady") for item in schedules)
        group["carryOverUnreadCount"] = 0
        group["status"] = min(
            (str(item.get("status") or "Scheduled") for item in schedules),
            key=lambda value: status_rank.get(value, 2),
            default="Scheduled",
        )
        zone_count = len(schedules)
        group["label"] = (
            f"{zone_count} zone{'s' if zone_count != 1 else ''} | "
            f"{group['billingMonth'] or group['startDate']}"
        )
        result.append(group)

    return result


def _natural_display_key(value) -> tuple:
    parts = re.split(r"(\d+)", str(value or "").lower())
    return tuple(int(part) if part.isdigit() else part for part in parts)


def _zone_schedule(group: dict, zone_name: str = "", schedule_id: str = "") -> dict:
    """Resolve a grouped route back to one zone-specific schedule."""
    schedules = list(group.get("viewSchedules") or group.get("schedules") or [])
    if schedule_id:
        matched = next(
            (item for item in schedules if str(item.get("scheduleId")) == str(schedule_id)),
            None,
        )
        if matched:
            return matched
        return {}
    return next(
        (item for item in schedules if str(item.get("zoneName")) == str(zone_name) and not item.get("isCarryOver")),
        next((item for item in schedules if str(item.get("zoneName")) == str(zone_name)), {}),
    )


def _normalize_shutdown_error(detail: str) -> str:
    lowered = (detail or "").lower()
    if "a password is required" in lowered or "password" in lowered or "interactive authentication required" in lowered:
        return (
            "Shutdown requires elevated privileges on this Raspberry Pi.\n\n"
            "Configure passwordless power-off for the app user, for example:\n"
            "sudo visudo\n"
            "Add: pi ALL=(ALL) NOPASSWD: /sbin/shutdown, /sbin/poweroff, /bin/systemctl"
        )
    return detail or "Power-off command failed."


def _friendly_save_target_text(value: str) -> str:
    normalized = (value or "").strip()
    mapping = {
        "Local SQLite Queue (Backend API retry pending)": "Saved on device, waiting to retry upload",
        "Backend API auto-sync on change": "Automatic backend sync is on",
        "Backend API unavailable": "Saved on device, backend unavailable",
        "Local SQLite Queue (offline)": "Saved on device while offline",
        "Local SQLite only": "Saved on device",
    }
    return mapping.get(normalized, normalized or "Saved on device")


def _friendly_backup_state_text(value: str) -> str:
    normalized = (value or "").strip()
    mapping = {
        "Not configured": "Not configured",
    }
    return mapping.get(normalized, normalized or "Not configured")


def _has_receipt_context_gaps(consumer: dict | None) -> bool:
    if not consumer:
        return False
    address = str(consumer.get("address") or consumer.get("consumer_address") or "").strip()
    if not address or address.lower() == "n/a":
        return True
    if not str(consumer.get("billing_month") or "").strip():
        return True
    if not str(consumer.get("date_covered_from") or "").strip():
        return True
    if not str(consumer.get("date_covered_to") or "").strip():
        return True
    return False


def _authoritative_bill_from_sync_result(result: dict | None) -> dict | None:
    if not isinstance(result, dict):
        return None
    response = result
    remote = result.get("remote")
    if isinstance(remote, dict):
        response = remote.get("Backend API") or remote.get("backend") or response
    if not isinstance(response, dict):
        return None
    if isinstance(response.get("data"), dict):
        response = response["data"]
    bill = response.get("bill")
    return dict(bill) if isinstance(bill, dict) and bill else None


class LoginBridge(QObject):
    loginSuccess = Signal(dict)
    loginFailed = Signal()
    loginBusyChanged = Signal()
    loginStatusChanged = Signal()
    loginAttemptFinished = Signal(bool, object, str)
    databasePreparationFinished = Signal(bool, str)
    errorMessageChanged = Signal()
    clearInputsRequested = Signal()

    def __init__(self, *, database_ready: bool = False) -> None:
        super().__init__()
        self._error_message = ""
        self._database_ready = database_ready
        self._database_preparing = False
        self._login_busy = not database_ready
        self._login_status = "Log In" if database_ready else "Preparing device..."
        self._sync_dal = None
        self.loginAttemptFinished.connect(self._finish_login_attempt)
        self.databasePreparationFinished.connect(self._finish_database_preparation)

    @Property(str, notify=errorMessageChanged)
    def errorMessage(self) -> str:
        return self._error_message

    @Property(bool, notify=loginBusyChanged)
    def loginBusy(self) -> bool:
        return self._login_busy

    @Property(str, notify=loginStatusChanged)
    def loginStatus(self) -> str:
        return self._login_status

    def prepare_database(self) -> None:
        if self._database_ready or self._database_preparing:
            return
        self._database_preparing = True
        self._login_busy = True
        self._login_status = "Preparing device..."
        self._error_message = ""
        self.loginBusyChanged.emit()
        self.loginStatusChanged.emit()
        self.errorMessageChanged.emit()

        def _task() -> None:
            try:
                init_db()
            except Exception as exc:
                self.databasePreparationFinished.emit(False, str(exc))
                return
            self.databasePreparationFinished.emit(True, "")

        threading.Thread(target=_task, daemon=True, name="device-database-prepare").start()

    @Slot(bool, str)
    def _finish_database_preparation(self, success: bool, message: str) -> None:
        self._database_preparing = False
        self._database_ready = success
        self._login_busy = False
        self._login_status = "Log In" if success else "Retry setup"
        self._error_message = "" if success else f"Unable to prepare device storage: {message}"
        self.loginBusyChanged.emit()
        self.loginStatusChanged.emit()
        self.errorMessageChanged.emit()

    def set_workspace_loading(self, loading: bool) -> None:
        self._login_busy = loading
        self._login_status = "Opening routes..." if loading else "Log In"
        self.loginBusyChanged.emit()
        self.loginStatusChanged.emit()

    @Slot(str, str)
    def attemptLogin(self, username, password):
        username = username.strip()
        password = password.strip()
        if self._login_busy:
            return
        if not self._database_ready:
            self.prepare_database()
            return
        if not username or not password:
            self._error_message = "Please enter username and password"
            self.errorMessageChanged.emit()
            self.loginFailed.emit()
            return

        self._login_busy = True
        self._login_status = "Logging in..."
        self._error_message = ""
        self.loginBusyChanged.emit()
        self.loginStatusChanged.emit()
        self.errorMessageChanged.emit()

        def _task() -> None:
            try:
                if HandheldSyncDataAccess is None or SyncConfig is None:
                    raise RuntimeError("Sync module is unavailable.")
                if self._sync_dal is None:
                    self._sync_dal = HandheldSyncDataAccess.from_env(fail_fast=True)
                user = self._sync_dal.authenticateMeterReader(username, password)
                cache_meter_reader_credentials(user, password)
                save_current_meter_reader(user)
                self.loginAttemptFinished.emit(True, user, "")
                return
            except PermissionError as exc:
                self.loginAttemptFinished.emit(False, None, str(exc) or "This account is not an active Meter Reader.")
                return
            except ValueError as exc:
                self.loginAttemptFinished.emit(False, None, str(exc) or "Invalid username or password.")
                return
            except Exception as exc:
                offline_error = str(exc) or "Unable to verify this account right now."

            cached_user = authenticate_user(username, password)
            if cached_user:
                save_current_meter_reader(cached_user)
                self.loginAttemptFinished.emit(True, cached_user, "")
                return
            self.loginAttemptFinished.emit(
                False,
                None,
                f"{offline_error} Connect once with this account before using offline login.",
            )

        threading.Thread(target=_task, daemon=True).start()

    @Slot(bool, object, str)
    def _finish_login_attempt(self, success: bool, user: object, message: str) -> None:
        self._login_busy = False
        self._login_status = "Log In"
        self.loginBusyChanged.emit()
        self.loginStatusChanged.emit()
        if success and isinstance(user, dict):
            self._error_message = ""
            self.errorMessageChanged.emit()
            self.loginSuccess.emit(user)
            return
        self._error_message = message or "Unable to log in."
        self.errorMessageChanged.emit()
        self.loginFailed.emit()

    def show_session_expired(self) -> None:
        self._error_message = "Session expired. Please log in again."
        self.errorMessageChanged.emit()


class AppBridge(QObject):
    # Tab property
    currentTabChanged = Signal()
    readerNameChanged = Signal()
    readerIdChanged = Signal()
    statusTimeChanged = Signal()
    batteryLevelChanged = Signal()
    paperStatusChanged = Signal()
    searchSuggestionsChanged = Signal()
    zoneConsumersChanged = Signal()
    progressDetailsVisibleChanged = Signal()
    logoutRequested = Signal()
    welcomeToastRequested = Signal(str)
    operationBusyChanged = Signal()
    operationBusyMessageChanged = Signal()
    alertRequested = Signal(str, str)
    receiptPreviewRequested = Signal(str, str)
    printPreviewRequested = Signal(str, str, str)
    printHistoryRequested = Signal()
    canReprintChanged = Signal()
    
    # Meter Entry properties
    zonesChanged = Signal()
    selectedZoneChanged = Signal()
    assignedRoutesChanged = Signal()
    selectedRouteChanged = Signal()
    searchQueryChanged = Signal()

    
    # Consumer info properties
    accountNoChanged = Signal()
    consumerNameChanged = Signal()
    previousReadingChanged = Signal()
    presentReadingChanged = Signal()
    dueDateChanged = Signal()
    consumptionChanged = Signal()
    validationColorChanged = Signal()
    validationMessageChanged = Signal()
    billingMonthOptionsChanged = Signal()
    selectedBillingMonthChanged = Signal()
    
    # Exception properties
    exceptionsChanged = Signal()
    selectedExceptionChanged = Signal()

    # Sync properties
    syncStatusChanged = Signal()
    syncStatusColorChanged = Signal()
    syncPendingCountChanged = Signal()
    syncReviewCountChanged = Signal()
    backendStatusChanged = Signal()
    backendPendingCountChanged = Signal()
    backendLastSyncChanged = Signal()
    saveTargetChanged = Signal()
    backupStateChanged = Signal()
    lastSyncChanged = Signal()
    lastPullMirrorChanged = Signal()
    lastPullCountChanged = Signal()
    autoPullEnabledChanged = Signal()
    autoPushEnabledChanged = Signal()
    autoSyncEnabledChanged = Signal()
    pullIntervalChanged = Signal()
    syncLogsChanged = Signal()
    backendLogsChanged = Signal()
    wifiStatusChanged = Signal()
    wifiStatusColorChanged = Signal()
    wifiNetworksChanged = Signal()
    wifiBusyChanged = Signal()
    testPrintBusyChanged = Signal()
    syncTaskFinished = Signal(object)
    syncProgress = Signal(str)
    wifiScanFinished = Signal(object, str)
    wifiConnectFinished = Signal(bool, str, str)
    wifiStatusResult = Signal(str, str)
    backendProbeFinished = Signal(object)
    powerOffFailed = Signal(str)
    testPrintFinished = Signal(bool, str)
    printPreviewBusyChanged = Signal()
    printHistoryRecordsChanged = Signal()
    printHistoryFiltersChanged = Signal()
    printHistoryDetailChanged = Signal()
    printExecutionFinished = Signal(object)
    printPreparationFinished = Signal(object)
    meterIssueSaveFinished = Signal(object)
    assignedDatasetFinished = Signal(object)
    heartbeatResult = Signal(int, int, object)
    sessionExpired = Signal()

    # Circular progress / dashboard stats
    overallPercentageChanged = Signal()
    overallFractionChanged = Signal()
    zoneReadFractionChanged = Signal()
    zoneCompletionPercentageChanged = Signal()
    zoneFlaggedCountChanged = Signal()
    zoneRemainingCountChanged = Signal()

    def __init__(self) -> None:
        super().__init__()
        self._current_tab = 0
        self._reader_name = "User"
        self._reader_id = ""
        self._meter_reader_account_id = ""

        self._status_time = datetime.now().strftime("%I:%M %p")
        self._battery_level = 85
        self._paper_status = "OK"
        self._search_suggestions = []
        self._zone_consumers = []
        self._zone_refreshing: set[str] = set()
        self._zone_refresh_attempted: set[str] = set()
        self._assigned_dataset_refreshing = False
        self._heartbeat_generation = 0
        self._heartbeat_in_flight = False
        self._heartbeat_thread = None
        self._heartbeat_authenticated = False
        self._heartbeat_retry_count = 0
        self._heartbeat_next_allowed = 0.0
        self._heartbeat_config_invalid = False
        self._progress_details_visible = False
        self._operation_busy = False
        self._operation_busy_message = ""
        self._last_receipt_entry = get_latest_receipt_print()
        self._last_receipt = self._last_receipt_entry["receipt_text"] if self._last_receipt_entry else None

        self._billing_month_offsets = [0, 1]
        self._selected_billing_month_offset = 0

        self._assigned_routes = []
        self._selected_route_id = ""
        self._route_selected_by_user = False
        self._selected_route_billing_date = ""
        self._zones = []
        self._selected_zone = ""
        self._search_query = ""
        self._selected_search_schedule_id = ""
        self._search_unread_only = False

        self._account_no = "-"
        self._consumer_name = "-"
        self._previous_reading = "-"
        self._present_reading = ""
        self._due_date = ""
        self._due_date_confirmed = False
        self._consumption = "-"
        self._validation_color = "#94a3b8"
        self._validation_message = "-"

        self._exceptions = ["None", "Stuck Meter", "Leaking", "No Access", "Broken Seal"]
        self._selected_exception = "None"

        self._sync_status = "Offline"
        self._sync_status_color = "#475569"
        self._sync_pending_count = 0
        self._sync_review_count = 0
        self._sync_review_summary = ""
        self._backend_status = "Offline"
        self._backend_pending_count = 0
        self._backend_last_sync = "Never"
        self._backend_endpoint = os.getenv("BACKEND_API_BASE_URL", "").rstrip("/") or "Not configured"
        self._save_target = "Local SQLite only"
        self._backup_state = "Not configured"
        self._last_sync = "Never"
        self._last_pull_mirror = 0
        self._last_pull_count = 0
        self._assignment_download_status = "Not downloaded yet"
        self._assignment_download_error = ""
        self._assignment_download_summary = ""
        self._auto_pull_enabled = False
        self._auto_push_enabled = False
        self._auto_sync_enabled = self._load_auto_sync_enabled()
        self._pull_interval = max(300, int(os.getenv("BACKEND_SYNC_INTERVAL_MS", "300000")) // 1000)
        self._sync_logs = "No sync activity yet."
        self._backend_logs = "No Backend API activity yet."
        self._sync_dal = None
        self._heartbeat_dal = None
        self._wifi_status = "Status: Checking..."
        self._wifi_status_color = "#526176"
        self._wifi_networks = []
        self._wifi_network_details = []
        self._wifi_busy = False
        self._wifi_scan_silent = False
        self._backend_probe_in_flight = False
        self._test_print_busy = False
        self._print_preview_busy = False
        self._pending_print_job = None
        self._print_history_records = []
        self._print_history_detail = None
        self._print_history_months = []
        self._selected_print_history_month = ""
        self._selected_print_history_action = ""
        self._print_history_search = ""

        self._overall_percentage = 0
        self._overall_fraction = "0/0"
        self._zone_read_fraction = "0/0"
        self._zone_completion_percentage = 0
        self._zone_flagged_count = 0
        self._zone_remaining_count = 0

        self._consumer = None
        self._clock_timer = QTimer(self)
        self._clock_timer.setInterval(60_000)
        self._clock_timer.timeout.connect(self._tick_status_clock)
        self._clock_timer.start()

        self.syncTaskFinished.connect(self._finish_sync_task)
        self.syncProgress.connect(self._show_sync_progress)
        self.wifiScanFinished.connect(self._finish_wifi_scan)
        self.wifiConnectFinished.connect(self._finish_wifi_connect)
        self.wifiStatusResult.connect(self._set_wifi_status)
        self.backendProbeFinished.connect(self._refresh_sync_snapshot)
        self.powerOffFailed.connect(self._finish_power_off_failure)
        self.testPrintFinished.connect(self._finish_test_print)
        self.printExecutionFinished.connect(self._finish_print_execution)
        self.printPreparationFinished.connect(self._finish_print_preparation)
        self.meterIssueSaveFinished.connect(self._finish_meter_issue_save)
        self.assignedDatasetFinished.connect(self._finish_assigned_consumer_dataset)
        self.heartbeatResult.connect(self._finish_heartbeat)

        self._heartbeat_timer = QTimer(self)
        self._heartbeat_timer.setInterval(60_000)
        self._heartbeat_timer.timeout.connect(self._start_heartbeat)

        self._wifi_timer = QTimer(self)
        self._wifi_timer.setInterval(5_000)
        self._wifi_timer.timeout.connect(self.refreshWifiStatus)
        self._wifi_timer.start()

        self._wifi_scan_timer = QTimer(self)
        self._wifi_scan_timer.setInterval(15_000)
        self._wifi_scan_timer.timeout.connect(self.refreshWifiNetworks)
        self._wifi_scan_timer.start()

        self._assignment_refresh_timer = QTimer(self)
        self._assignment_refresh_timer.setInterval(self._pull_interval * 1000)
        self._assignment_refresh_timer.timeout.connect(self._run_auto_pull)

        self._refresh_search_suggestions()
        self._refresh_zone_consumers()
        self.refreshPrintHistory()
        self.update_stats()
        self._init_sync()
        self.refreshWifiStatus()
        self.refreshWifiNetworks()

    # Properties
    @Property(int, notify=zoneRemainingCountChanged)
    def zoneRemainingCount(self) -> int:
        return self._zone_remaining_count
    @Property(int, notify=currentTabChanged)
    def currentTab(self) -> int:
        return self._current_tab

    @currentTab.setter
    def currentTab(self, val: int) -> None:
        if self._current_tab != val:
            self._current_tab = val
            self.currentTabChanged.emit()

    @Property(str, notify=readerNameChanged)
    def readerName(self) -> str:
        return self._reader_name

    @Property(str, notify=readerIdChanged)
    def readerId(self) -> str:
        return self._reader_id

    @Property(str, notify=statusTimeChanged)
    def statusTime(self) -> str:
        return self._status_time

    @Property(int, notify=batteryLevelChanged)
    def batteryLevel(self) -> int:
        return self._battery_level

    @Property(str, notify=paperStatusChanged)
    def paperStatus(self) -> str:
        return self._paper_status

    @Property(list, notify=searchSuggestionsChanged)
    def searchSuggestions(self) -> list:
        return self._search_suggestions

    @Property(list, notify=zoneConsumersChanged)
    def zoneConsumers(self) -> list:
        return self._zone_consumers

    @Property(bool, notify=progressDetailsVisibleChanged)
    def progressDetailsVisible(self) -> bool:
        return self._progress_details_visible

    @Property(bool, notify=operationBusyChanged)
    def operationBusy(self) -> bool:
        return self._operation_busy

    @Property(str, notify=operationBusyMessageChanged)
    def operationBusyMessage(self) -> str:
        return self._operation_busy_message

    @Property(bool, notify=canReprintChanged)
    def canReprint(self) -> bool:
        return self._last_receipt is not None

    def set_user(self, user: dict, login_dal=None) -> None:
        self.stop_heartbeat()
        self._reader_name = reader_display_name(user)
        self._reader_id = str(user.get('account_id') or user.get('id') or '')
        self._meter_reader_account_id = str(user.get('account_id') or user.get('id') or "").strip()
        if self._sync_dal:
            self._sync_dal.setAuthenticatedSession(
                user.get("session_token"),
                self._meter_reader_account_id or None,
            )
        self._heartbeat_dal = self._sync_dal or login_dal
        if self._heartbeat_dal and self._heartbeat_dal is not self._sync_dal:
            self._heartbeat_dal.setAuthenticatedSession(
                user.get("session_token"), self._meter_reader_account_id or None,
            )
        self.readerNameChanged.emit()
        self.readerIdChanged.emit()
        self._last_receipt_entry = get_latest_receipt_print()
        self._last_receipt = self._last_receipt_entry["receipt_text"] if self._last_receipt_entry else None
        self.canReprintChanged.emit()
        self._route_selected_by_user = False
        self._refresh_local_assignment_views()
        self._heartbeat_authenticated = bool(user.get("session_token") and self._heartbeat_dal)
        if self._heartbeat_authenticated:
            self._heartbeat_config_invalid = False
            self._heartbeat_timer.start()
            self._start_heartbeat()
        QTimer.singleShot(100, self._start_assigned_consumer_dataset_refresh)

    def _start_heartbeat(self) -> None:
        if (not self._heartbeat_authenticated or self._heartbeat_in_flight
                or self._heartbeat_config_invalid
                or time.monotonic() < self._heartbeat_next_allowed):
            return
        self._heartbeat_in_flight = True
        generation = self._heartbeat_generation
        dal = self._heartbeat_dal

        def _task() -> None:
            try:
                status, response = dal.sendDeviceHeartbeat()
            except Exception as exc:
                status, response = 0, {"error": str(exc)}
            self.heartbeatResult.emit(generation, status, response)

        self._heartbeat_thread = threading.Thread(
            target=_task, daemon=True, name="device-heartbeat"
        )
        self._heartbeat_thread.start()

    def _finish_heartbeat(self, generation: int, status: int, response: object) -> None:
        if generation != self._heartbeat_generation or not self._heartbeat_authenticated:
            return
        self._heartbeat_in_flight = False
        if 200 <= status < 300:
            self._heartbeat_retry_count = 0
            self._heartbeat_next_allowed = 0.0
            return

        detail = ""
        if isinstance(response, dict):
            detail = str(response.get("message") or response.get("error") or "")
        token = str(getattr(getattr(self._heartbeat_dal, "remote", None), "_session_token", "") or "")
        if token:
            detail = detail.replace(token, "[redacted]")
        detail = detail[:200].strip()
        if status == 401:
            self._heartbeat_timer.stop()
            self._heartbeat_authenticated = False
            self._heartbeat_dal.setAuthenticatedSession(None, None)
            self._heartbeat_dal._audit(
                None, "failed",
                "Device online session expired. Sign in online again to sync; local readings remain available.",
            )
            self.sessionExpired.emit()
        elif status == 400:
            self._heartbeat_timer.stop()
            self._heartbeat_config_invalid = True
            self._heartbeat_dal._audit(None, "failed", f"Device heartbeat configuration error: {detail or 'HTTP 400'}")
        elif status == 429 or status >= 500:
            self._heartbeat_retry_count += 1
            delay = min(300, 60 * (2 ** min(self._heartbeat_retry_count, 3)))
            self._heartbeat_next_allowed = time.monotonic() + delay
            self._heartbeat_dal._audit(None, "failed", f"Device heartbeat HTTP {status}; retry in {delay}s.")
        else:
            warning = detail or (f"HTTP {status}" if status else "network unavailable")
            self._heartbeat_dal._audit(None, "failed", f"Device heartbeat warning: {warning}")

    def stop_heartbeat(self) -> None:
        self._heartbeat_timer.stop()
        self._heartbeat_authenticated = False
        self._heartbeat_generation += 1
        worker = self._heartbeat_thread
        if worker and worker.is_alive() and worker is not threading.current_thread():
            worker.join(timeout=11)
        self._heartbeat_thread = None
        self._heartbeat_in_flight = False
        self._heartbeat_retry_count = 0
        self._heartbeat_next_allowed = 0.0
        self._heartbeat_config_invalid = False
        if self._heartbeat_dal:
            self._heartbeat_dal.setAuthenticatedSession(None, None)
            self._heartbeat_dal = None

    @Slot()
    def showWelcomeToast(self) -> None:
        self.welcomeToastRequested.emit(f"Welcome, {self._reader_name}!" if self._reader_name else "Welcome!")

    def _set_operation_busy(self, busy: bool, message: str = "") -> None:
        if self._operation_busy != busy:
            self._operation_busy = busy
            self.operationBusyChanged.emit()
        if self._operation_busy_message != message:
            self._operation_busy_message = message
            self.operationBusyMessageChanged.emit()

    def clear_user(self) -> None:
        self.stop_heartbeat()
        clear_current_meter_reader()
        if self._sync_dal:
            self._sync_dal.setAuthenticatedSession(None, None)
        self._reader_name = "User"
        self._reader_id = ""
        self._meter_reader_account_id = ""
        self._zones = []
        self._selected_zone = ""
        self._assigned_routes = []
        self._selected_route_id = ""
        self._route_selected_by_user = False
        self._selected_route_billing_date = ""
        self._zone_consumers = []
        self._search_suggestions = []
        self._search_query = ""
        self._selected_search_schedule_id = ""
        self.readerNameChanged.emit()
        self.readerIdChanged.emit()
        self.zonesChanged.emit()
        self.selectedZoneChanged.emit()
        self.zoneConsumersChanged.emit()
        self.searchSuggestionsChanged.emit()
        self.searchQueryChanged.emit()

    def _tick_status_clock(self) -> None:
        self._status_time = datetime.now().strftime("%I:%M %p")
        self.statusTimeChanged.emit()
        self._start_backend_probe()

    def _route_schedules(self, zone_name: str | None = None) -> list[dict]:
        route = self._selected_route()
        schedules = list(route.get("viewSchedules") or route.get("schedules") or [])
        effective_zone = str(zone_name if zone_name is not None else self._selected_zone or "")
        if effective_zone and effective_zone != "All zones":
            schedules = [item for item in schedules if str(item.get("zoneName")) == effective_zone]
        return schedules

    def _schedule_for_consumer(self, consumer: dict | None = None) -> dict:
        source = consumer or self._consumer or {}
        explicit_schedule_id = str(source.get("schedule_id") or "")
        zone_name = str(source.get("zone_name") or self._selected_zone or "")
        return _zone_schedule(self._selected_route(), zone_name, explicit_schedule_id)

    def _selected_route_consumer_rows(self) -> list[dict]:
        rows: list[dict] = []
        for schedule in self._route_schedules():
            schedule_id = schedule.get("scheduleId")
            zone_name = str(schedule.get("zoneName") or "")
            if not schedule_id or not zone_name:
                continue
            for row in get_zone_consumers_with_status(
                zone_name,
                schedule_date=self.selectedBillingDate,
                meter_reader_id=self._meter_reader_account_id or None,
                schedule_id=schedule_id,
            ):
                if schedule.get("isCarryOver") and row.get("is_read"):
                    continue
                item = dict(row)
                item["schedule_id"] = int(schedule_id)
                item["is_carry_over"] = bool(schedule.get("isCarryOver"))
                rows.append(item)
        current_ids = {int(item["id"]) for item in rows if not item["is_carry_over"]}
        rows = [
            item for item in rows
            if not item["is_carry_over"] or int(item["id"]) not in current_ids
        ]
        # A grouped route can contain several zone-specific schedules. Sort the
        # combined list once while preserving every item's original schedule_id.
        return sort_and_mark_nearby(rows)

    def _search_selected_route(self, query: str, limit: int, unread_only: bool) -> list[dict]:
        matches: list[dict] = []
        seen: set[tuple[int, str]] = set()
        for schedule in self._route_schedules():
            schedule_id = schedule.get("scheduleId")
            zone_name = str(schedule.get("zoneName") or "")
            if not schedule_id or not zone_name:
                continue
            rows = search_consumers_by_zone(
                query,
                zone_name,
                limit=max(limit, 50),
                unread_only=unread_only or bool(schedule.get("isCarryOver")),
                schedule_date=self.selectedBillingDate,
                meter_reader_id=self._meter_reader_account_id or None,
                schedule_id=schedule_id,
            )
            for row in rows:
                item = dict(row)
                item["schedule_id"] = int(schedule_id)
                item["is_carry_over"] = bool(schedule.get("isCarryOver"))
                key = (int(item.get("id") or 0), str(schedule_id))
                if key not in seen:
                    seen.add(key)
                    matches.append(item)
        visible = {
            (int(item["id"]), int(item["schedule_id"]))
            for item in self._selected_route_consumer_rows()
        }
        return sort_and_mark_nearby([
            item for item in matches
            if (int(item["id"]), int(item["schedule_id"])) in visible
        ])[:limit]

    def _refresh_search_suggestions(self) -> None:
        query = self._search_query.strip()
        if not query:
            self._search_suggestions = []
            self.searchSuggestionsChanged.emit()
            return

        try:
            self._search_suggestions = self._search_selected_route(query, 6, self._search_unread_only)
        except Exception:
            self._search_suggestions = []
        self.searchSuggestionsChanged.emit()

    def _refresh_zone_consumers(self) -> None:
        if not self._selected_zone:
            self._zone_consumers = []
            self.zoneConsumersChanged.emit()
            return

        try:
            self._zone_consumers = self._selected_route_consumer_rows()
        except Exception:
            self._zone_consumers = []
        self.zoneConsumersChanged.emit()
        if not self._zone_consumers:
            self._start_selected_zone_consumer_refresh(self._selected_zone)

    def _start_selected_zone_consumer_refresh(self, zone_name: str) -> None:
        if not zone_name or not self._sync_dal or not self._meter_reader_account_id:
            return
        if getattr(self, "_assigned_dataset_refreshing", False) or getattr(self, "_operation_busy", False):
            return
        if zone_name in self._zone_refreshing or zone_name in self._zone_refresh_attempted:
            return
        self._zone_refreshing.add(zone_name)
        self._zone_refresh_attempted.add(zone_name)

        def _task() -> None:
            try:
                with self._sync_dal.operation_lock:
                    date_from, date_to = _assignment_download_window()
                    consumers = self._sync_dal.loadAssignedConsumers(
                        self._meter_reader_account_id,
                        None if zone_name == "All zones" else zone_name,
                        date_from,
                        date_to,
                        require_online=True,
                    )
                    mirrored, mirror_report = _mirror_assigned_consumer_rows(self._sync_dal, consumers)
                pulled_zones = sorted({
                    str(item.get("zone_name") or "").strip()
                    for item in consumers if isinstance(item, dict) and str(item.get("zone_name") or "").strip()
                })
                context_pull = self._sync_dal.prefetchAssignedConsumerContexts(consumers)
                self.assignedDatasetFinished.emit({
                    "success": True, "pulled": len(consumers), "mirrored": mirrored,
                    "zone": zone_name, "pulled_zones": pulled_zones,
                    "context_pull": context_pull,
                    "download_summary": _summarize_assignment_download(consumers, mirror_report),
                    "skipped_records": mirror_report["skipped"],
                })
            except Exception as exc:
                self.assignedDatasetFinished.emit({"success": False, "error": str(exc), "zone": zone_name})

        threading.Thread(target=_task, daemon=True).start()

    @Property(list, notify=zonesChanged)
    def zones(self) -> list:
        return self._zones

    @Property(list, notify=assignedRoutesChanged)
    def assignedRoutes(self) -> list:
        today = datetime.now().date().isoformat()
        return [route for route in self._assigned_routes if str(route.get("dueDate") or today) >= today]

    @Property(list, notify=assignedRoutesChanged)
    def pastRoutes(self) -> list:
        today = datetime.now().date().isoformat()
        return [route for route in self._assigned_routes if str(route.get("dueDate") or today) < today]

    @Property(str, notify=selectedRouteChanged)
    def selectedRouteId(self) -> str:
        return self._selected_route_id

    @selectedRouteId.setter
    def selectedRouteId(self, value: str) -> None:
        route_id = str(value or "").strip()
        route = next((item for item in self._assigned_routes if str(item.get("scheduleId")) == route_id), None)
        if not route or route_id == self._selected_route_id:
            return
        self._selected_route_id = route_id
        self._route_selected_by_user = True
        self._zones = list(route.get("zones") or [])
        self._selected_zone = "All zones" if self._zones else ""
        self._selected_route_billing_date = str(route.get("billingDate") or route.get("startDate") or "")
        self.selectedRouteChanged.emit()
        self.zonesChanged.emit()
        self.selectedZoneChanged.emit()
        self.assignedRoutesChanged.emit()
        self.selectedRouteChanged.emit()
        self.selectedBillingMonthChanged.emit()
        self._refresh_search_suggestions()
        self._refresh_zone_consumers()
        self.update_stats()
        if not route.get("offlineReady"):
            self._start_selected_zone_consumer_refresh(self._selected_zone)

    def _selected_route(self) -> dict:
        return next(
            (item for item in self._assigned_routes if str(item.get("scheduleId")) == self._selected_route_id),
            {},
        )

    @Property(str, notify=selectedRouteChanged)
    def selectedRoutePeriod(self) -> str:
        route = self._selected_route()
        start = str(route.get("startDate") or "-")
        due = str(route.get("dueDate") or "-")
        return f"{start} to {due}"

    @Property(str, notify=selectedRouteChanged)
    def selectedRouteBillingMonth(self) -> str:
        return str(self._selected_route().get("billingMonth") or "-")

    @Property(str, notify=selectedRouteChanged)
    def selectedRouteStatus(self) -> str:
        return str(self._selected_route().get("status") or "-")

    @Property(int, notify=selectedRouteChanged)
    def selectedRouteCarryOverCount(self) -> int:
        return int(self._selected_route().get("carryOverUnreadCount") or 0)

    @Property(bool, notify=selectedRouteChanged)
    def selectedRouteIsPast(self) -> bool:
        due_date = str(self._selected_route().get("dueDate") or "")
        return bool(due_date and due_date < datetime.now().date().isoformat())

    @Property(bool, notify=selectedRouteChanged)
    def routeOfflineReady(self) -> bool:
        return bool(self._selected_route().get("offlineReady"))

    @Property(str, notify=selectedRouteChanged)
    def routeCacheMessage(self) -> str:
        route = self._selected_route()
        if not route:
            return "No assigned route selected"
        if route.get("offlineReady"):
            return "Route ready for offline use"
        schedules = list(route.get("schedules") or [])
        ready_count = sum(1 for item in schedules if item.get("offlineReady"))
        if ready_count:
            return f"{ready_count}/{len(schedules)} zones ready offline"
        return "Connect to download and verify this route"

    @Property(str, notify=selectedZoneChanged)
    def selectedZone(self) -> str:
        return self._selected_zone

    @selectedZone.setter
    def selectedZone(self, val: str) -> None:
        if val in self._zones and self._selected_zone != val:
            self._selected_zone = val
            self.selectedZoneChanged.emit()
            self._refresh_search_suggestions()
            self._refresh_zone_consumers()
            self.update_stats()

    @Property(str, notify=searchQueryChanged)
    def searchQuery(self) -> str:
        return self._search_query

    @searchQuery.setter
    def searchQuery(self, val: str) -> None:
        if self._search_query != val:
            self._search_query = val
            self._selected_search_schedule_id = ""
            self.searchQueryChanged.emit()
            self._refresh_search_suggestions()

    @Property(list, notify=searchSuggestionsChanged)
    def searchSuggestions(self) -> list:
        return self._search_suggestions

    # Consumer Details properties
    @Property(str, notify=accountNoChanged)
    def accountNo(self) -> str:
        return self._account_no

    @Property(str, notify=consumerNameChanged)
    def consumerName(self) -> str:
        return self._consumer_name

    @Property(str, notify=previousReadingChanged)
    def previousReading(self) -> str:
        return self._previous_reading

    @Property(str, notify=presentReadingChanged)
    def presentReading(self) -> str:
        return self._present_reading

    @presentReading.setter
    def presentReading(self, val: str) -> None:
        if self._present_reading != val:
            self._present_reading = val
            self.presentReadingChanged.emit()
            self.calculate_consumption()

    @Property(str, notify=dueDateChanged)
    def dueDate(self) -> str:
        return self._due_date

    @Property(bool, notify=dueDateChanged)
    def dueDateIsConfirmed(self) -> bool:
        return self._due_date_confirmed

    @Property(str, notify=consumptionChanged)
    def consumption(self) -> str:
        return self._consumption

    @Property(str, notify=validationColorChanged)
    def validationColor(self) -> str:
        return self._validation_color

    @Property(str, notify=validationMessageChanged)
    def validationMessage(self) -> str:
        return self._validation_message

    @Property(list, notify=billingMonthOptionsChanged)
    def billingMonthOptions(self) -> list:
        now = datetime.now()
        options = []
        for offset in self._billing_month_offsets:
            target = _add_months(now, offset)
            options.append(
                {
                    "label": "Current Month" if offset == 0 else "Next Month",
                    "detail": target.strftime("%B %Y"),
                    "offset": offset,
                }
            )
        return options

    @Property(int, notify=selectedBillingMonthChanged)
    def selectedBillingMonthOffset(self) -> int:
        return self._selected_billing_month_offset

    @selectedBillingMonthOffset.setter
    def selectedBillingMonthOffset(self, val: int) -> None:
        try:
            offset = int(val)
        except (TypeError, ValueError):
            offset = 0
        if offset not in self._billing_month_offsets:
            offset = 0
        if self._selected_billing_month_offset != offset:
            self._selected_billing_month_offset = offset
            self.selectedBillingMonthChanged.emit()
            if self._consumer and not self._due_date_confirmed:
                self._due_date = self._default_due_date_for_consumer(self._consumer)
                self.dueDateChanged.emit()
            self.update_stats()
            self._refresh_search_suggestions()
            self._refresh_zone_consumers()

    @Property(str, notify=selectedBillingMonthChanged)
    def selectedBillingDate(self) -> str:
        route_date = _normalize_iso_date(self._selected_route_billing_date)
        if route_date:
            return route_date
        return self._selected_reading_date().isoformat()

    # Exception properties
    @Property(list, notify=exceptionsChanged)
    def exceptions(self) -> list:
        return self._exceptions

    @Property(str, notify=selectedExceptionChanged)
    def selectedException(self) -> str:
        return self._selected_exception

    @selectedException.setter
    def selectedException(self, val: str) -> None:
        if self._selected_exception != val:
            self._selected_exception = val
            self.selectedExceptionChanged.emit()

    # Sync Settings properties
    @Property(str, notify=syncStatusChanged)
    def syncStatus(self) -> str:
        return self._sync_status

    @Property(str, notify=syncStatusColorChanged)
    def syncStatusColor(self) -> str:
        return self._sync_status_color

    @Property(int, notify=syncPendingCountChanged)
    def syncPendingCount(self) -> int:
        return self._sync_pending_count

    @Property(int, notify=syncReviewCountChanged)
    def syncReviewCount(self) -> int:
        return self._sync_review_count

    @Property(str, notify=syncReviewCountChanged)
    def syncReviewSummary(self) -> str:
        return self._sync_review_summary

    @Property(str, notify=backendStatusChanged)
    def backendStatus(self) -> str:
        return self._backend_status

    @Property(int, notify=backendPendingCountChanged)
    def backendPendingCount(self) -> int:
        return self._backend_pending_count

    @Property(str, notify=backendLastSyncChanged)
    def backendLastSync(self) -> str:
        return self._backend_last_sync

    @Property(str, constant=True)
    def backendEndpoint(self) -> str:
        return self._backend_endpoint

    @Property(str, notify=saveTargetChanged)
    def saveTarget(self) -> str:
        return self._save_target

    @Property(str, notify=backupStateChanged)
    def backupState(self) -> str:
        return self._backup_state

    @Property(str, notify=lastSyncChanged)
    def lastSync(self) -> str:
        return self._last_sync

    @Property(int, notify=lastPullMirrorChanged)
    def lastPullMirror(self) -> int:
        return self._last_pull_mirror

    @Property(int, notify=lastPullCountChanged)
    def lastPullCount(self) -> int:
        return self._last_pull_count

    @Property(str, notify=syncStatusChanged)
    def assignmentDownloadStatus(self) -> str:
        return self._assignment_download_status

    @Property(str, notify=lastPullCountChanged)
    def assignmentDownloadSummary(self) -> str:
        return self._assignment_download_summary

    @Property(bool, notify=autoPullEnabledChanged)
    def autoPullEnabled(self) -> bool:
        return False

    @autoPullEnabled.setter
    def autoPullEnabled(self, val: bool) -> None:
        if self._auto_pull_enabled:
            self._auto_pull_enabled = False
            self.autoPullEnabledChanged.emit()

    @Property(bool, notify=autoPushEnabledChanged)
    def autoPushEnabled(self) -> bool:
        return False

    @autoPushEnabled.setter
    def autoPushEnabled(self, val: bool) -> None:
        if self._auto_push_enabled:
            self._auto_push_enabled = False
            self.autoPushEnabledChanged.emit()

    @Property(bool, notify=autoSyncEnabledChanged)
    def autoSyncEnabled(self) -> bool:
        return self._auto_sync_enabled

    @autoSyncEnabled.setter
    def autoSyncEnabled(self, val: bool) -> None:
        normalized = bool(val)
        if self._auto_sync_enabled == normalized:
            return
        previous = self._auto_sync_enabled
        self._auto_sync_enabled = normalized
        try:
            if not normalized and self._sync_dal:
                self._sync_dal.stop_sync_worker()
            set_app_setting("auto_sync_enabled", "1" if normalized else "0")
            self.autoSyncEnabledChanged.emit()
            self._apply_auto_sync_setting()
        except Exception as exc:
            self._auto_sync_enabled = previous
            diagnostic = format_sync_error("Updating automatic sync settings", exc, self._backend_endpoint)
            self._sync_status = "Sync Failed"
            self._sync_status_color = "#EF4444"
            self._backend_status = "Sync Failed"
            self._sync_logs = diagnostic
            self._backend_logs = diagnostic
            self.autoSyncEnabledChanged.emit()
            self.syncLogsChanged.emit()
            self.backendLogsChanged.emit()
            self._emit_sync_state()

    @Property(int, notify=pullIntervalChanged)
    def pullInterval(self) -> int:
        return self._pull_interval

    @pullInterval.setter
    def pullInterval(self, val: int) -> None:
        normalized = max(300, int(val or self._pull_interval or 300))
        if self._pull_interval != normalized:
            self._pull_interval = normalized
            self.pullIntervalChanged.emit()
            if self._sync_dal and self._auto_sync_enabled:
                self._sync_dal.stop_sync_worker()
                self._sync_dal.start_sync_worker(interval_seconds=self._pull_interval)
            self._reset_auto_pull_timer()

    @Property(str, notify=syncLogsChanged)
    def syncLogs(self) -> str:
        return self._sync_logs

    @Property(str, notify=backendLogsChanged)
    def backendLogs(self) -> str:
        return self._backend_logs

    @Property(str, notify=wifiStatusChanged)
    def wifiStatus(self) -> str:
        return self._wifi_status

    @Property(str, notify=wifiStatusColorChanged)
    def wifiStatusColor(self) -> str:
        return self._wifi_status_color

    @Property(list, notify=wifiNetworksChanged)
    def wifiNetworks(self) -> list:
        return self._wifi_networks

    @Property(list, notify=wifiNetworksChanged)
    def wifiNetworkDetails(self) -> list:
        return self._wifi_network_details

    @Property(bool, notify=wifiBusyChanged)
    def wifiBusy(self) -> bool:
        return self._wifi_busy

    @Property(bool, notify=testPrintBusyChanged)
    def testPrintBusy(self) -> bool:
        return self._test_print_busy

    @Property(bool, notify=printPreviewBusyChanged)
    def printPreviewBusy(self) -> bool:
        return self._print_preview_busy

    @Property(list, notify=printHistoryRecordsChanged)
    def printHistoryRecords(self) -> list:
        return self._print_history_records

    @Property(list, notify=printHistoryFiltersChanged)
    def printHistoryMonthOptions(self) -> list:
        options = [{"label": "All months", "value": ""}]
        for month in self._print_history_months:
            try:
                label = datetime.strptime(month, "%Y-%m").strftime("%B %Y")
            except ValueError:
                label = month
            options.append({"label": label, "value": month})
        return options

    @Property(str, notify=printHistoryFiltersChanged)
    def selectedPrintHistoryMonth(self) -> str:
        return self._selected_print_history_month

    @Property(list, notify=printHistoryFiltersChanged)
    def printHistoryActionOptions(self) -> list:
        return [
            {"label": "All bills", "value": ""},
            {"label": "Originals", "value": "print"},
            {"label": "Reprints", "value": "reprint"},
        ]

    @Property(str, notify=printHistoryFiltersChanged)
    def selectedPrintHistoryAction(self) -> str:
        return self._selected_print_history_action

    @Property(str, notify=printHistoryDetailChanged)
    def printHistoryDetailTitle(self) -> str:
        if not self._print_history_detail:
            return ""
        return f"Receipt #{self._print_history_detail.get('id', '')}"

    @Property(str, notify=printHistoryDetailChanged)
    def printHistoryDetailText(self) -> str:
        if not self._print_history_detail:
            return ""
        return str(self._print_history_detail.get("receipt_text") or "")

    @Property(bool, notify=printHistoryDetailChanged)
    def hasPrintHistoryDetail(self) -> bool:
        return self._print_history_detail is not None

    # Circular progress stats properties
    @Property(int, notify=overallPercentageChanged)
    def overallPercentage(self) -> int:
        return self._overall_percentage

    @Property(str, notify=overallFractionChanged)
    def overallFraction(self) -> str:
        return self._overall_fraction

    @Property(str, notify=zoneReadFractionChanged)
    def zoneReadFraction(self) -> str:
        return self._zone_read_fraction

    @Property(int, notify=zoneCompletionPercentageChanged)
    def zoneCompletionPercentage(self) -> int:
        return self._zone_completion_percentage

    @Property(int, notify=zoneFlaggedCountChanged)
    def zoneFlaggedCount(self) -> int:
        return self._zone_flagged_count

    def _emit_sync_state(self) -> None:
        self.syncStatusChanged.emit()
        self.syncStatusColorChanged.emit()
        self.syncPendingCountChanged.emit()
        self.syncReviewCountChanged.emit()
        self.backendStatusChanged.emit()
        self.backendPendingCountChanged.emit()
        self.backendLastSyncChanged.emit()
        self.saveTargetChanged.emit()
        self.backupStateChanged.emit()
        self.lastSyncChanged.emit()
        self.lastPullMirrorChanged.emit()

    def _load_auto_sync_enabled(self) -> bool:
        raw = get_app_setting("auto_sync_enabled", "1")
        return str(raw).strip().lower() not in {"0", "false", "no", "off", ""}

    def _apply_auto_sync_setting(self) -> None:
        if not self._sync_dal:
            self._emit_sync_state()
            return
        if self._auto_sync_enabled:
            self._sync_dal.start_sync_worker(interval_seconds=self._pull_interval)
        else:
            self._sync_dal.stop_sync_worker()
        self._reset_auto_pull_timer()
        self._refresh_sync_snapshot()

    def _init_sync(self) -> None:
        if HandheldSyncDataAccess is None or SyncConfig is None:
            self._sync_status = "Sync Failed"
            self._sync_status_color = "#EF4444"
            self._sync_logs = "Sync module is unavailable."
            self._backend_status = "Unavailable"
            self._backend_logs = self._sync_logs
            self.syncLogsChanged.emit()
            self.backendLogsChanged.emit()
            self._emit_sync_state()
            return
        try:
            cfg = SyncConfig.from_env(fail_fast=False)
            self._backend_endpoint = cfg.backend_api_base_url or "Not configured"
            if not cfg.sync_enabled:
                self._sync_status = "Offline"
                self._sync_status_color = "#526176"
                self._sync_logs = "Handheld sync is disabled in the environment."
                self._backend_status = "Disabled"
                self._backend_logs = self._sync_logs
                self.syncLogsChanged.emit()
                self.backendLogsChanged.emit()
                self._reset_auto_pull_timer()
                self._emit_sync_state()
                return
            self._sync_dal = HandheldSyncDataAccess.from_env(fail_fast=True)
            self._apply_auto_sync_setting()
        except Exception as exc:
            self._sync_dal = None
            self._sync_status = "Sync Failed"
            self._sync_status_color = "#EF4444"
            self._sync_logs = format_sync_error("Initializing device sync", exc, self._backend_endpoint)
            self._backend_status = "Sync Failed"
            self._backend_logs = self._sync_logs
            self.syncLogsChanged.emit()
            self.backendLogsChanged.emit()
            self._emit_sync_state()

    def _refresh_sync_snapshot(self, snapshot: dict | None = None) -> None:
        if snapshot is not None:
            self._backend_probe_in_flight = False
        if not self._sync_dal:
            self._emit_sync_state()
            return
        if snapshot is None:
            # Health checks can wait on slow Funnel connections. Keep all
            # network and queue inspection work off the Qt event thread.
            self._start_backend_probe()
            return
        try:
            was_backend_online = self._backend_status == "Online"
            if snapshot.get("probe_error"):
                raise RuntimeError(snapshot["probe_error"])
            self._sync_status = str(snapshot.get("status", "Offline"))
            self._sync_status_color = "#10B981" if self._sync_status == "Online" else "#526176"
            download_error = str(getattr(self, "_assignment_download_error", "") or "")
            if snapshot.get("has_failed") or (snapshot.get("backend_online") and download_error):
                self._sync_status = "Sync Failed"
                self._sync_status_color = "#EF4444"
            self._sync_pending_count = int(snapshot.get("pending_count", 0))
            self._sync_review_count = int(snapshot.get("review_count", 0))
            self._sync_review_summary = "\n".join(
                f"Consumer {row.get('consumer_id')} · Schedule {row.get('schedule_id')} · "
                f"{row.get('billing_reference') or 'Reference pending'}\n"
                f"Reason: {row.get('reason') or 'Check Sync Diagnostics for details.'}"
                for row in snapshot.get("review_readings", [])
            )
            self._backend_status = "Online" if snapshot.get("backend_online") else "Offline"
            if self._backend_status == "Online" and not was_backend_online:
                self._start_heartbeat()
            self._backend_pending_count = int(snapshot.get("backend_pending_count", 0))
            self._backend_last_sync = str(snapshot.get("backend_last_sync_time") or "Never")
            self._save_target = _friendly_save_target_text(str(snapshot.get("save_target", "Local SQLite only")))
            self._backup_state = _friendly_backup_state_text(str(snapshot.get("backup_state", "Not configured")))
            self._last_sync = str(snapshot.get("last_sync_time") or "Never")
            entries = self._sync_dal.get_recent_audit_entries(limit=25)
            diagnostic_header = (
                f"Endpoint: {self._backend_endpoint}\n"
                f"Backend status: {self._backend_status}\n"
                f"Queued readings: {self._backend_pending_count}\n"
                f"Needs review: {self._sync_review_count}\n"
                f"Automatic sync: {'Enabled' if self._auto_sync_enabled else 'Disabled'}\n"
                f"Assignment download: {getattr(self, '_assignment_download_status', 'Not downloaded yet')}"
            )
            if getattr(self, "_assignment_download_summary", ""):
                diagnostic_header += "\n" + self._assignment_download_summary
            if download_error:
                diagnostic_header += "\n\n" + download_error
            if self._sync_review_summary:
                diagnostic_header += "\n" + self._sync_review_summary
            health_error = str(snapshot.get("backend_health_error") or "").strip()
            if self._backend_status == "Offline" and health_error:
                diagnostic_header += "\n\n" + format_sync_error(
                    "Checking Backend API connectivity", health_error, self._backend_endpoint
                )
            activity = "\n\n".join(
                f"[{row.get('created_at', '')}] {str(row.get('status', '')).upper()}\n{row.get('message', '')}"
                for row in entries
            ) or "No sync activity yet."
            self._sync_logs = diagnostic_header + "\n\n" + activity
            backend_entries = [
                row for row in entries
                if any(
                    marker in str(row.get("message", "")).lower()
                    for marker in ("backend api", "endpoint:", "uploading reading")
                )
            ]
            backend_activity = "\n\n".join(
                f"[{row.get('created_at', '')}] {str(row.get('status', '')).upper()}\n{row.get('message', '')}"
                for row in backend_entries
            ) or "No Backend API activity yet."
            self._backend_logs = diagnostic_header + "\n\n" + backend_activity
            self.syncLogsChanged.emit()
            self.backendLogsChanged.emit()
        except Exception as exc:
            self._sync_status = "Sync Failed"
            self._sync_status_color = "#EF4444"
            self._sync_logs = format_sync_error("Refreshing sync diagnostics", exc, self._backend_endpoint)
            self._backend_status = "Sync Failed"
            self._backend_logs = self._sync_logs
            self.syncLogsChanged.emit()
            self.backendLogsChanged.emit()
        self._emit_sync_state()

    def _start_backend_probe(self) -> None:
        if not self._sync_dal or self._backend_probe_in_flight:
            return
        self._backend_probe_in_flight = True
        dal = self._sync_dal

        def _task() -> None:
            try:
                snapshot = dal.get_sync_snapshot()
            except Exception as exc:
                snapshot = {"probe_error": str(exc)}
            self.backendProbeFinished.emit(snapshot)

        threading.Thread(target=_task, daemon=True).start()

    def _reset_auto_pull_timer(self) -> None:
        if not hasattr(self, "_assignment_refresh_timer"):
            return
        self._assignment_refresh_timer.setInterval(self._pull_interval * 1000)
        if self._sync_dal and self._auto_sync_enabled:
            self._assignment_refresh_timer.start()
        else:
            self._assignment_refresh_timer.stop()

    def _refresh_local_assignment_views(self) -> None:
        routes = get_assigned_routes(self._meter_reader_account_id or None)
        self._assigned_routes = _group_route_rows(routes)
        valid_ids = {str(route.get("scheduleId")) for route in self._assigned_routes}
        if self._selected_route_id not in valid_ids:
            self._route_selected_by_user = False
        if not self._route_selected_by_user:
            self._selected_route_id = str(self._assigned_routes[0].get("scheduleId")) if self._assigned_routes else ""
        selected_route = self._selected_route()
        if selected_route:
            self._zones = list(selected_route.get("zones") or [])
            if self._selected_zone not in self._zones:
                self._selected_zone = "All zones" if self._zones else ""
            self._selected_route_billing_date = str(selected_route.get("billingDate") or selected_route.get("startDate") or "")
        else:
            self._zones = []
            self._selected_zone = ""
            self._selected_route_billing_date = ""
        self.assignedRoutesChanged.emit()
        self.selectedRouteChanged.emit()
        self.zonesChanged.emit()
        self.selectedZoneChanged.emit()
        self._refresh_search_suggestions()
        self._refresh_zone_consumers()
        self.update_stats()
        consumer = getattr(self, "_consumer", None)
        if consumer and not getattr(self, "_due_date_confirmed", False):
            latest_payment_date = AppBridge._default_due_date_for_consumer(self, consumer)
            if latest_payment_date != getattr(self, "_due_date", ""):
                consumer["schedule_payment_due_date"] = latest_payment_date or None
                self._due_date = latest_payment_date
                self.dueDateChanged.emit()

    def _mirror_assigned_schedules(self, date_from: str, date_to: str) -> int:
        if not self._sync_dal or not self._meter_reader_account_id:
            return 0
        schedules = getattr(self._sync_dal, "last_assignment_schedules", None)
        if schedules is None:
            raise RuntimeError("Fresh assigned schedules have not been downloaded; cached routes remain available.")
        updated = replace_reading_schedules_from_sync(schedules, self._meter_reader_account_id, date_from, date_to)
        reconcile = getattr(self._sync_dal, "reconcileScheduleReadings", None)
        if callable(reconcile):
            reconcile(schedules)
        return updated

    def _start_assigned_consumer_dataset_refresh(self) -> None:
        if not self._meter_reader_account_id or not self._sync_dal:
            if not self._sync_dal:
                self._sync_logs = "Assigned consumer refresh skipped: sync is not available."
                self.syncLogsChanged.emit()
            self._refresh_local_assignment_views()
            return
        if self._assigned_dataset_refreshing or getattr(self, "_operation_busy", False):
            return
        self._assigned_dataset_refreshing = True

        def _task() -> None:
            try:
                with self._sync_dal.operation_lock:
                    date_from, date_to = _assignment_download_window()
                    consumers = self._sync_dal.loadAssignedConsumers(
                        self._meter_reader_account_id,
                        None,
                        date_from,
                        date_to,
                        require_online=True,
                    )
                    schedule_count = self._mirror_assigned_schedules(date_from, date_to)
                    mirrored, mirror_report = _mirror_assigned_consumer_rows(self._sync_dal, consumers)
                pulled_zones = sorted(
                    {
                        str(item.get("zone_name") or "").strip()
                        for item in consumers
                        if isinstance(item, dict) and str(item.get("zone_name") or "").strip()
                    }
                )
                context_pull = self._sync_dal.prefetchAssignedConsumerContexts(consumers)
                self.assignedDatasetFinished.emit(
                    {
                        "success": True,
                        "pulled": len(consumers),
                        "mirrored": mirrored,
                        "schedules": schedule_count,
                        "pulled_zones": pulled_zones,
                        "context_pull": context_pull,
                        "download_summary": _summarize_assignment_download(consumers, mirror_report),
                        "skipped_records": mirror_report["skipped"],
                    }
                )
            except Exception as exc:
                self._sync_dal._audit(None, "failed", format_sync_error(
                    "Downloading assigned schedules and consumers", exc, self._backend_endpoint
                ))
                self.assignedDatasetFinished.emit({"success": False, "error": str(exc)})

        threading.Thread(target=_task, daemon=True).start()

    def _verify_cached_routes(self, pulled_zones: list[str]) -> None:
        """Persist readiness only after the assignment and its local consumer rows agree."""
        verified_zones = {str(zone or "").strip() for zone in pulled_zones if str(zone or "").strip()}
        if not verified_zones or not self._meter_reader_account_id:
            return
        for route in get_assigned_routes(self._meter_reader_account_id):
            zone_name = str(route.get("zone_name") or "").strip()
            if zone_name not in verified_zones:
                continue
            schedule_date = _billing_month_date(route.get("billing_month"), str(route.get("start_date") or ""))
            cached_rows = get_zone_consumers_with_status(
                zone_name,
                schedule_date=schedule_date,
                meter_reader_id=self._meter_reader_account_id,
                schedule_id=route.get("schedule_id"),
            )
            mark_route_cache_verified(route.get("schedule_id"), self._meter_reader_account_id, len(cached_rows))

    def _finish_assigned_consumer_dataset(self, result: dict) -> None:
        self._assigned_dataset_refreshing = False
        zone_name = str(result.get("zone") or "")
        if zone_name:
            self._zone_refreshing.discard(zone_name)
        if not result.get("success"):
            self._assignment_download_status = "Download failed; using cached records"
            self._assignment_download_summary = ""
            self.lastPullCountChanged.emit()
            self._assignment_download_error = format_sync_error(
                "Downloading assigned schedules and consumers", result.get("error", "Unknown error"), self._backend_endpoint
            )
            if zone_name:
                self._zone_refresh_attempted.discard(zone_name)
            self._sync_logs = f"Assigned schedule refresh failed: {result.get('error', 'Unknown error')}"
            self.syncLogsChanged.emit()
        else:
            self._assignment_download_status = "Fresh backend data"
            if result.get("skipped_records"):
                self._assignment_download_status += f"; {result['skipped_records']} rows skipped"
            self._assignment_download_error = ""
            self._assignment_download_summary = str(result.get("download_summary") or "")
            if zone_name:
                self._zone_refresh_attempted.discard(zone_name)
            else:
                self._zone_refresh_attempted.clear()
            self._last_pull_count = int(result.get("pulled", self._last_pull_count))
            self._last_pull_mirror = int(result.get("mirrored", self._last_pull_mirror))
            pulled_zones = result.get("pulled_zones") or []
            if zone_name and not pulled_zones:
                pulled_zones = [zone_name]
            self._verify_cached_routes(pulled_zones)
            if pulled_zones:
                context_pull = result.get("context_pull") or {}
                context_status = (
                    "Offline cache used" if context_pull.get("skipped") else
                    f"Consumer records cached: {context_pull.get('refreshed', 0)}/{context_pull.get('requested', 0)}"
                )
                if context_pull.get("failed"):
                    context_status += "\nSome records are missing. Reconnect and sync again before offline work."
                self._sync_logs = (
                    f"Assigned consumers refreshed.\n"
                    f"Pulled: {self._last_pull_count}\n"
                    f"Mirrored: {self._last_pull_mirror}\n"
                    f"Zones: {', '.join(str(zone) for zone in pulled_zones)}\n"
                    f"{context_status}"
                )
                self.syncLogsChanged.emit()
            self.lastPullCountChanged.emit()
            self.lastPullMirrorChanged.emit()
        self._refresh_local_assignment_views()
        self._refresh_sync_snapshot()

    def _refresh_assigned_consumer_dataset(self) -> None:
        if not self._meter_reader_account_id:
            self._refresh_local_assignment_views()
            return
        if self._sync_dal:
            try:
                date_from, date_to = _assignment_download_window()
                consumers = self._sync_dal.loadAssignedConsumers(
                    self._meter_reader_account_id,
                    None,
                    date_from,
                    date_to,
                    require_online=True,
                )
                self._mirror_assigned_schedules(date_from, date_to)
                replace_consumers_from_sync(consumers)
            except Exception as exc:
                self._sync_logs = f"Assigned schedule refresh failed: {exc}"
                self.syncLogsChanged.emit()
        self._refresh_local_assignment_views()

    def _run_auto_pull(self) -> None:
        if not self._auto_sync_enabled or not self._sync_dal or not self._meter_reader_account_id:
            return
        self._start_assigned_consumer_dataset_refresh()

    def _ensure_current_consumer_receipt_context(self, force_refresh: bool = False) -> None:
        if not self._consumer or not self._sync_dal:
            return
        if not force_refresh and not _has_receipt_context_gaps(self._consumer):
            return
        consumer_id = self._consumer.get("id")
        try:
            consumer_id_int = int(consumer_id)
        except (TypeError, ValueError):
            return
        try:
            refreshed = _display_consumer_context(self._sync_dal, consumer_id_int)
        except Exception:
            return
        if not refreshed:
            return
        selected_assignment = {
            key: self._consumer.get(key)
            for key in (
                "schedule_id", "schedule_date", "schedule_due_date", "billing_cycle",
                "reading_route_id", "assignment_order", "zone_name",
            )
            if self._consumer.get(key) not in (None, "")
        }
        selected_policy = {
            key: self._consumer.get(key)
            for key in ("due_days", "late_fee")
            if self._consumer.get(key) not in (None, "")
        }
        replace_consumers_from_sync([refreshed])
        self._reload_current_consumer_from_db()
        # Keep response-only billing details such as unpaid_bills in memory;
        # the normalized consumer cache intentionally stores only scalar data.
        current = dict(self._consumer or {})
        current.update(refreshed)
        current.update(selected_assignment)
        current["schedule_payment_due_date"] = AppBridge._default_due_date_for_consumer(self, current) or None
        for key, value in selected_policy.items():
            if refreshed.get(key) in (None, ""):
                current[key] = value
        self._consumer = current
        if not getattr(self, "_due_date_confirmed", False):
            self._due_date = current.get("schedule_payment_due_date") or ""
            if hasattr(self, "dueDateChanged"):
                self.dueDateChanged.emit()

    @Slot(bool)
    def setAutoSyncEnabled(self, enabled: bool) -> None:
        self.autoSyncEnabled = enabled

    def _reload_current_consumer_from_db(self) -> None:
        if not self._consumer:
            return
        meter_no = (self._consumer.get("meter_no") or "").strip()
        if not meter_no:
            return
        schedule = self._schedule_for_consumer(self._consumer)
        refreshed = search_consumer(
            meter_no,
            unread_only=False,
            schedule_date=self.selectedBillingDate,
            meter_reader_id=self._meter_reader_account_id or None,
            schedule_id=schedule.get("scheduleId"),
        )
        if refreshed is None:
            return
        refreshed["schedule_id"] = int(schedule["scheduleId"]) if schedule.get("scheduleId") else None
        if self._due_date_confirmed and self._consumer.get("id") == refreshed.get("id"):
            confirmed_date = _normalize_iso_date(self._consumer.get("due_date"))
            if confirmed_date:
                refreshed["due_date"] = confirmed_date
        self._consumer = refreshed
        self._account_no = str(refreshed.get("acct_no") or refreshed["id"])
        self._consumer_name = refreshed["name"]
        self._previous_reading = _format_reading(refreshed["previous_reading"])
        self._due_date = (
            _normalize_iso_date(refreshed.get("due_date"))
            if self._due_date_confirmed else self._default_due_date_for_consumer(refreshed)
        ) or ""
        self.accountNoChanged.emit()
        self.consumerNameChanged.emit()
        self.previousReadingChanged.emit()
        self.dueDateChanged.emit()

    def _selected_reading_date(self) -> datetime.date:
        route = self._selected_route()
        reading_date = _route_reading_date(
            self._selected_route_billing_date,
            str(route.get("startDate") or ""),
            str(route.get("dueDate") or ""),
        )
        if reading_date:
            return reading_date
        return _add_months(datetime.now(), self._selected_billing_month_offset).date()

    def _default_due_date_for_consumer(self, consumer: dict | None = None, reading_date: str | None = None) -> str:
        # This form creates a new bill. A previous bill's due date cannot be
        # presented as the payment deadline for the new reading.
        source = consumer or self._consumer or {}
        linked_date = get_schedule_payment_due_date(source.get("schedule_id"))
        if linked_date is not None:
            return _normalize_iso_date(linked_date) or ""
        schedule_for_consumer = getattr(self, "_schedule_for_consumer", None)
        schedule = schedule_for_consumer(source) if schedule_for_consumer else {}
        return (
            _normalize_iso_date(source.get("schedule_payment_due_date"))
            or _normalize_iso_date(schedule.get("paymentDueDate"))
            or payment_due_date(
                _normalize_iso_date(reading_date) or datetime.now().date().isoformat(),
                source.get("due_days"),
            ).isoformat()
        )

    def _load_consumer_for_new_bill(self, consumer: dict) -> None:
        self._consumer = consumer
        self._account_no = str(consumer.get("acct_no") or consumer["id"])
        self._consumer_name = consumer["name"]
        self._previous_reading = _format_reading(consumer["previous_reading"])
        self._present_reading = ""
        self._due_date = self._default_due_date_for_consumer(consumer)
        self._due_date_confirmed = False
        self._consumption = "-"
        self._validation_color = "#94a3b8"
        self._validation_message = "-"
        self._current_tab = 0
        self.accountNoChanged.emit()
        self.consumerNameChanged.emit()
        self.previousReadingChanged.emit()
        self.presentReadingChanged.emit()
        self.dueDateChanged.emit()
        self.consumptionChanged.emit()
        self.validationColorChanged.emit()
        self.validationMessageChanged.emit()
        self.currentTabChanged.emit()

    def _finish_sync_task(self, result: dict) -> None:
        keep_busy = bool(result.get("keep_busy"))
        if not keep_busy:
            self._set_operation_busy(False, "")
        if result.get("kind") == "error":
            self._sync_status = "Sync Failed"
            self._sync_status_color = "#EF4444"
            self._sync_logs = str(result.get("error", "Sync failed"))
            self.syncLogsChanged.emit()
            self._emit_sync_state()
            if not result.get("silent"):
                self.alertRequested.emit("Sync Failed", self._sync_logs)
            return

        if "pulled" in result:
            self._last_pull_mirror = int(result.get("mirrored", self._last_pull_mirror))
            self._last_pull_count = int(result.get("pulled", self._last_pull_count))
            self._assignment_download_error = str((result.get("result") or {}).get("pull_error") or "")
            self._assignment_download_status = "Download failed; using cached records" if self._assignment_download_error else "Fresh backend data"
            skipped_records = int((result.get("result") or {}).get("skipped_records", 0))
            if not self._assignment_download_error and skipped_records:
                self._assignment_download_status += f"; {skipped_records} rows skipped"
            self._assignment_download_summary = (
                "" if self._assignment_download_error else str(result.get("download_summary") or "")
            )
            self.lastPullCountChanged.emit()
        self._refresh_local_assignment_views()
        self._reload_current_consumer_from_db()
        self._refresh_sync_snapshot()
        if result.get("kind") == "sync" and not result.get("silent"):
            sync_result = result.get("result", {})
            context_result = result.get("context_pull") or {}
            pull_error = str(sync_result.get("pull_error") or "").strip()
            errors = [str(item).strip() for item in sync_result.get("errors", []) if str(item).strip()]
            pull_line = f"\nPulled: {self._last_pull_count}\nMirrored: {self._last_pull_mirror}"
            if "pulled" in result:
                pull_line += f"\nAssignment download: {self._assignment_download_status}"
                if self._assignment_download_summary:
                    pull_line += "\n" + self._assignment_download_summary
            review_line = f"\nNeeds review: {sync_result.get('needs_review', getattr(self, '_sync_review_count', 0))}"
            reference_line = (
                f"\nOffline references ready: {sync_result.get('offline_references_ready', 0)}"
                f"\nReference failures: {sync_result.get('offline_reference_failures', 0)}"
            )
            error_line = f"\nPull warning: {pull_error}" if pull_error else ""
            context_line = (
                f"\nOffline records: {context_result.get('refreshed', 0)}/{context_result['requested']}"
                f"\nOffline records not downloaded: {context_result.get('failed', 0)}"
                if context_result.get("requested") else
                "\nOffline record download skipped: backend unavailable."
                if context_result.get("skipped") else ""
            )
            first_error_line = f"\n\nFirst problem:\n{errors[0]}" if errors else ""
            has_problems = bool(
                pull_error or errors or sync_result.get("failed") or sync_result.get("conflicts")
                or sync_result.get("offline_reference_failures") or sync_result.get("skipped_records")
                or context_result.get("failed") or context_result.get("skipped")
            )
            self.alertRequested.emit(
                "Sync Finished with Problems" if has_problems else "Sync Complete",
                f"Synced: {sync_result.get('synced', 0)}\nFailed: {sync_result.get('failed', 0)}\nConflicts: {sync_result.get('conflicts', 0)}{review_line}{pull_line}{reference_line}{context_line}{error_line}{first_error_line}",
            )

    def _save_to_sync_layer(
        self,
        consumer_id: int,
        present: float,
        consumption: float,
        exception: str,
        flagged: bool,
        reading_date: str | None = None,
        due_date: str | None = None,
        *,
        sync_reading_id: str | None = None,
        captured_at: str | None = None,
        schedule_id: int | str | None = None,
        schedule_date: str | None = None,
        schedule_due_date: str | None = None,
        billing_cycle: str | None = None,
        reading_route_id: int | str | None = None,
        assignment_order: int | str | None = None,
        bill_sync_id: str | None = None,
        bill_date: str | None = None,
        billing_reference: str | None = None,
        previous_reading_date_snapshot: str | None = None,
        coverage_snapshot: dict | None = None,
        wait_for_result: bool = False,
    ) -> dict | None:
        if not self._sync_dal:
            return
        consumer = self._consumer or {}
        route = self._selected_route()
        schedule = self._schedule_for_consumer(consumer)
        effective_reading_date = _normalize_iso_date(reading_date) or datetime.now().date().isoformat()
        effective_schedule_date = (
            _normalize_iso_date(schedule_date)
            or _normalize_iso_date(schedule.get('startDate'))
            or _normalize_iso_date(route.get("startDate"))
            or _normalize_iso_date(self.selectedBillingDate)
            or effective_reading_date
        )
        effective_schedule_due_date = (
            _normalize_iso_date(schedule_due_date)
            or _normalize_iso_date(route.get("dueDate"))
            or effective_schedule_date
        )
        schedule_payment_due_date = self._default_due_date_for_consumer(consumer, effective_reading_date)
        payload = {
            "reading_id": sync_reading_id or str(uuid.uuid4()),
            "consumer_id": consumer_id,
            "acct_no": consumer.get("acct_no"),
            "meter_no": consumer.get("meter_no"),
            "zone_name": consumer.get("zone_name"),
            "classification_id": consumer.get("classification_id"),
            "classification_name": consumer.get("classification_name"),
            "minimum_cubic": consumer.get("minimum_cubic"),
            "minimum_rate": consumer.get("minimum_rate"),
            "excess_rate_per_cubic": consumer.get("excess_rate_per_cubic"),
            "water_meter_fee": consumer.get("water_meter_fee"),
            "meter_maintenance_fee": consumer.get("water_meter_fee", consumer.get("meter_maintenance_fee")),
            "connection_fee": consumer.get("connection_fee"),
            "membership_fee": consumer.get("membership_fee"),
            "meter_reader_id": self._meter_reader_account_id or None,
            "previous_reading": consumer.get("previous_reading"),
            "previous_reading_date": previous_reading_date_snapshot,
            "present_reading": present,
            "consumption": consumption,
            "exception": exception,
            "is_flagged": bool(flagged),
            "reading_date": effective_reading_date,
            "captured_at": captured_at or datetime.now().astimezone().isoformat(),
            "schedule_id": int(schedule_id) if schedule_id not in (None, "") else (int(schedule.get("scheduleId")) if schedule.get("scheduleId") else None),
            "schedule_date": effective_schedule_date,
            "schedule_due_date": effective_schedule_due_date,
            "schedule_payment_due_date": schedule_payment_due_date,
            "billing_cycle": billing_cycle or route.get("billingMonth") or consumer.get("billing_month"),
            "reading_route_id": reading_route_id if reading_route_id not in (None, "") else consumer.get("reading_route_id"),
            "assignment_order": assignment_order if assignment_order not in (None, "") else consumer.get("assignment_order"),
            "reading_status": "valid",
            "reading_sync_status": "pending",
            "billing_calculation_status": "Pending server calculation",
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "bill_sync_id": bill_sync_id,
            "bill_date": _normalize_iso_date(bill_date) or effective_reading_date,
            "billing_reference": billing_reference,
        }
        frozen_coverage = coverage_snapshot if coverage_snapshot is not None else consumer
        for key in ('coverage_policy_version','coverage_from','coverage_to','previous_schedule_date','previous_reading','baseline_required'):
            payload[key] = frozen_coverage.get(key)

        def _save() -> dict | None:
            try:
                with self._sync_dal.operation_lock:
                    if self._auto_sync_enabled:
                        return self._sync_dal.saveMeterReading(payload)
                    return self._sync_dal.queueMeterReading(payload)
            except Exception as exc:
                diagnostic = format_sync_error("Saving reading to the local retry queue", exc, self._backend_endpoint)
                if wait_for_result:
                    raise RuntimeError(diagnostic) from exc
                self._sync_logs = diagnostic
                self._backend_status = "Sync Failed"
                self._backend_logs = self._sync_logs
                self.syncLogsChanged.emit()
                self.backendStatusChanged.emit()
                self.backendLogsChanged.emit()
                return None

        if wait_for_result:
            return _save()

        def _task() -> None:
            _save()
            self._refresh_sync_snapshot()

        threading.Thread(target=_task, daemon=True).start()
        return None

    def _set_wifi_busy(self, busy: bool, status: str | None = None) -> None:
        self._wifi_busy = busy
        if status is not None:
            self._wifi_status = status
            self.wifiStatusChanged.emit()
        self.wifiBusyChanged.emit()

    def _set_wifi_status(self, status: str, color: str) -> None:
        was_connected = self._wifi_status.startswith("Status: Connected")
        self._wifi_status = status
        self._wifi_status_color = color
        self.wifiStatusChanged.emit()
        self.wifiStatusColorChanged.emit()
        is_connected = status.startswith("Status: Connected")
        if is_connected and not was_connected:
            self._start_heartbeat()
            self._start_reconnect_sync()
            if getattr(self, "_auto_sync_enabled", False):
                self._start_assigned_consumer_dataset_refresh()

    def _start_reconnect_sync(self) -> None:
        if not self._auto_sync_enabled or not self._sync_dal:
            return
        try:
            if not self._sync_dal.listPendingBackendReadings():
                return
        except Exception:
            return

        def _task() -> None:
            try:
                with self._sync_dal.operation_lock:
                    result = self._sync_dal.syncPendingReadings()
                self.syncTaskFinished.emit({"kind": "sync", "result": result, "silent": True, "mirrored": 0})
            except Exception as exc:
                self.syncTaskFinished.emit(
                    {"kind": "error", "error": format_sync_error("Synchronizing after reconnect", exc, self._backend_endpoint), "silent": True}
                )

        threading.Thread(target=_task, daemon=True).start()

    def _start_wifi_scan(self, silent: bool = False) -> None:
        if self._wifi_busy:
            return
        self._wifi_scan_silent = silent
        self._set_wifi_busy(True)
        if not silent:
            self._wifi_status_color = "#2563EB"
            self.wifiStatusColorChanged.emit()

        def _task() -> None:
            try:
                if os.name != "nt":
                    self.wifiScanFinished.emit(scan_wifi_networks(rescan=not silent), "")
                    return
                command = ["netsh", "wlan", "show", "networks", "mode=bssid"]
                result = subprocess.run(
                    command,
                    capture_output=True,
                    text=True,
                    timeout=20,
                    check=False,
                )
                if result.returncode != 0:
                    detail = (result.stderr or result.stdout or "Wi-Fi scan failed").strip()
                    if os.name == "nt" and ("location permission" in detail.lower() or "requires elevation" in detail.lower()):
                        detail = "Windows requires Location services for Wi-Fi scanning. Enable Location in Privacy & security, then scan again."
                    raise RuntimeError(detail)
                names = sorted({
                    match.group(1).strip()
                    for line in result.stdout.splitlines()
                    if (match := re.match(r"^\s*SSID\s+\d+\s*:\s*(.+)$", line))
                    and match.group(1).strip()
                })
                networks = [{"ssid": name, "security": "Not detected", "mode": "unknown"} for name in names]
                self.wifiScanFinished.emit(networks, "")
            except FileNotFoundError:
                tool = "netsh" if os.name == "nt" else "nmcli"
                self.wifiScanFinished.emit([], f"Wi-Fi utility '{tool}' is not installed.")
            except subprocess.TimeoutExpired:
                self.wifiScanFinished.emit([], "Wi-Fi scan timed out. Please try again.")
            except Exception as exc:
                self.wifiScanFinished.emit([], str(exc))

        threading.Thread(target=_task, daemon=True).start()

    @Slot()
    def scanWifiNetworks(self) -> None:
        self._start_wifi_scan(False)

    @Slot()
    def refreshWifiNetworks(self) -> None:
        if self._current_tab != 2:
            return
        self._start_wifi_scan(True)

    def _finish_wifi_scan(self, networks: list, error: str) -> None:
        self._set_wifi_busy(False)
        silent = self._wifi_scan_silent
        self._wifi_scan_silent = False
        if error:
            if not silent:
                self._set_wifi_status(f"Status: Error - {error}", "#EF4444")
                self.alertRequested.emit("Wi-Fi Scan Failed", error)
            return
        names = [row["ssid"] for row in networks]
        if self._wifi_networks != names or self._wifi_network_details != networks:
            self._wifi_networks = names
            self._wifi_network_details = list(networks)
            self.wifiNetworksChanged.emit()
        self.refreshWifiStatus()
        if silent:
            return
        if self._wifi_status.startswith("Status: Connected"):
            return
        if names:
            self._set_wifi_status(f"Status: Scan Complete ({len(networks)} found)", "#10B981")
        else:
            self._set_wifi_status("Status: No networks found", "#F59E0B")

    @Slot(str, str)
    @Slot(str, str, str)
    def connectWifiNetwork(self, ssid: str, password: str, security: str = "auto") -> None:
        if not ssid.strip():
            self.alertRequested.emit("Wi-Fi", "Enter or select a Wi-Fi network first.")
            return
        if os.name == "nt":
            message = "Wi-Fi connection is available on the Raspberry Pi. Windows mode supports network scanning and status checks for UI testing."
            self._set_wifi_status("Status: Windows development mode", "#F59E0B")
            self.alertRequested.emit("Raspberry Pi Wi-Fi", message)
            return
        if self._wifi_busy:
            return
        self._set_wifi_busy(True, f"Status: Connecting to {ssid}...")
        self._wifi_status_color = "#2563EB"
        self.wifiStatusColorChanged.emit()
        detected_mode = next((row["mode"] for row in self._wifi_network_details if row["ssid"] == ssid), "")

        def _task() -> None:
            try:
                connect_wifi_network(ssid, password, security, detected_mode=detected_mode)
                self.wifiConnectFinished.emit(True, ssid, "")
            except Exception as exc:
                self.wifiConnectFinished.emit(False, ssid, str(exc))

        threading.Thread(target=_task, daemon=True).start()

    def _finish_wifi_connect(self, success: bool, ssid: str, detail: str) -> None:
        if success and (detail != "status-only" or self._wifi_status != f"Status: Connected to {ssid}"):
            self._start_backend_probe()
        if detail == "status-only":
            self._set_wifi_status(f"Status: Connected to {ssid}", "#10B981")
            return
        self._set_wifi_busy(False)
        if success:
            self._set_wifi_status(f"Status: Connected to {ssid}", "#10B981")
            self.alertRequested.emit("Wi-Fi Connected", f"Connected to {ssid} successfully.")
        else:
            self._set_wifi_status(f"Status: Error - {detail}", "#EF4444")
            self.alertRequested.emit("Wi-Fi Connection Failed", detail)

    @Slot()
    def refreshWifiStatus(self) -> None:
        if self._wifi_busy:
            return

        def _task() -> None:
            try:
                if os.name == "nt":
                    result = subprocess.run(
                        ["netsh", "wlan", "show", "interfaces"],
                        capture_output=True,
                        text=True,
                        timeout=5,
                        check=False,
                    )
                    if result.returncode != 0:
                        detail = (result.stderr or result.stdout or "Unable to check Wi-Fi status").strip()
                        if "requires elevation" in detail.lower() or "access WLAN information" in detail:
                            self.wifiStatusResult.emit("Status: Raspberry Pi Wi-Fi (Windows preview)", "#F59E0B")
                            return
                        raise RuntimeError(detail)
                    connected = re.search(r"^\s*State\s*:\s*connected\s*$", result.stdout, re.MULTILINE | re.IGNORECASE)
                    ssid_match = re.search(r"^\s*SSID\s*:\s*(.+)$", result.stdout, re.MULTILINE | re.IGNORECASE)
                    if connected and ssid_match:
                        self.wifiStatusResult.emit(f"Status: Connected to {ssid_match.group(1).strip()}", "#10B981")
                    elif "There is no wireless interface" in result.stdout:
                        self.wifiStatusResult.emit("Status: No Wi-Fi adapter detected", "#F59E0B")
                    else:
                        self.wifiStatusResult.emit("Status: Disconnected", "#526176")
                    return
                result = subprocess.run(
                    ["nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "dev", "status"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                    check=False,
                    env={**os.environ, "LC_ALL": "C"},
                )
                if result.returncode != 0:
                    raise RuntimeError((result.stderr or result.stdout or "Unable to check Wi-Fi status").strip())
                wifi_found = False
                for line in result.stdout.splitlines():
                    parts = split_nmcli_fields(line)
                    if len(parts) < 4 or parts[1].strip() != "wifi":
                        continue
                    wifi_found = True
                    if parts[2].strip() == "connected":
                        ssid = connected_wifi_ssid(parts[0], parts[3])
                        self.wifiConnectFinished.emit(True, ssid, "status-only")
                        return
                status = "Status: Disconnected" if wifi_found else "Status: Error - No Wi-Fi adapter detected"
                color = "#526176" if wifi_found else "#F59E0B"
                self.wifiStatusResult.emit(status, color)
            except FileNotFoundError:
                tool = "netsh" if os.name == "nt" else "nmcli"
                self.wifiStatusResult.emit(f"Status: Wi-Fi utility '{tool}' is not installed", "#F59E0B")
            except subprocess.TimeoutExpired:
                self.wifiStatusResult.emit("Status: Wi-Fi status check timed out", "#F59E0B")
            except Exception as exc:
                self.wifiStatusResult.emit(f"Status: Error - {exc}", "#EF4444")

        threading.Thread(target=_task, daemon=True).start()

    # Actions / slots
    @Slot()
    def searchConsumer(self) -> None:
        query = self._search_query.strip()
        if not query:
            return

        matches = []
        if self._selected_search_schedule_id:
            schedule = _zone_schedule(self._selected_route(), schedule_id=self._selected_search_schedule_id)
            if schedule:
                matches = search_consumers_by_zone(
                    query, str(schedule.get("zoneName") or ""), limit=1,
                    unread_only=self._search_unread_only, schedule_date=self.selectedBillingDate,
                    meter_reader_id=self._meter_reader_account_id or None,
                    schedule_id=schedule.get("scheduleId"),
                )
                for item in matches:
                    item["schedule_id"] = int(schedule["scheduleId"])
                visible = {
                    (int(item["id"]), int(item["schedule_id"]))
                    for item in self._selected_route_consumer_rows()
                }
                matches = [
                    item for item in matches
                    if (int(item["id"]), int(item["schedule_id"])) in visible
                ]
        if not matches:
            matches = self._search_selected_route(query, 1, self._search_unread_only)
        consumer = matches[0] if matches else None

        if consumer is None:
            self._consumer = None
            self._account_no = "-"
            self._consumer_name = "Consumer not found"
            self._previous_reading = "-"
            self._present_reading = ""
            self._due_date = ""
            self._due_date_confirmed = False
            self._consumption = "-"
        else:
            self._consumer = consumer
            self._account_no = str(consumer.get("acct_no") or consumer["id"])
            self._consumer_name = consumer["name"]
            self._previous_reading = _format_reading(consumer["previous_reading"])
            self._present_reading = ""
            self._due_date = self._default_due_date_for_consumer(consumer)
            self._due_date_confirmed = False
            self._consumption = "-"

        self.accountNoChanged.emit()
        self.consumerNameChanged.emit()
        self.previousReadingChanged.emit()
        self.presentReadingChanged.emit()
        self.dueDateChanged.emit()
        self.consumptionChanged.emit()

    @Slot(str)
    @Slot(str, str)
    def selectSearchSuggestion(self, meter_no: str, schedule_id: str = "") -> None:
        self._search_query = meter_no
        self._selected_search_schedule_id = str(schedule_id or "")
        self.searchQueryChanged.emit()
        self._refresh_search_suggestions()
        self.searchConsumer()

    @Slot()
    def openProgressDetails(self) -> None:
        self._progress_details_visible = True
        self.progressDetailsVisibleChanged.emit()
        self._refresh_zone_consumers()

    @Slot()
    def closeProgressDetails(self) -> None:
        self._progress_details_visible = False
        self.progressDetailsVisibleChanged.emit()

    @Slot(int)
    @Slot(int, str)
    def reprintZoneConsumer(self, consumer_id: int, schedule_id: str = "") -> None:
        rows = self._selected_route_consumer_rows()
        row = next((
            item for item in rows
            if int(item.get("id", -1)) == consumer_id
            and (not schedule_id or str(item.get("schedule_id")) == str(schedule_id))
        ), None)
        if not row or not row.get("is_read"):
            self.alertRequested.emit("No Receipt", "No saved reading is available for this consumer.")
            return
        present = _to_float(row.get("reading_value") or 0)
        consumption = _to_float(row.get("consumption") or 0)
        previous = present - consumption
        latest_entry = get_latest_receipt_print(consumer_id)
        latest_receipt_matches_current_row = False
        if latest_entry:
            latest_present = _to_float(latest_entry.get("present_reading"))
            latest_consumption = _to_float(latest_entry.get("consumption"))
            latest_exception = str(latest_entry.get("exception") or "None")
            latest_reading_date = str(latest_entry.get("reading_date") or "").split("T", 1)[0].split(" ", 1)[0]
            row_reading_date = str(row.get("reading_date") or "").split("T", 1)[0].split(" ", 1)[0]
            latest_receipt_matches_current_row = (
                latest_present == present
                and latest_consumption == consumption
                and latest_exception == str(row.get("exception") or "None")
                and latest_reading_date == row_reading_date
            )
        if (latest_entry and latest_receipt_matches_current_row
                and _receipt_billing_reference(latest_entry.get("receipt_text"))):
            receipt = self._refresh_saved_receipt_penalty(latest_entry)
            latest_entry = {**latest_entry, "receipt_text": receipt}
        else:
            try:
                context = _display_consumer_context(self._sync_dal, int(consumer_id)) if self._sync_dal else {}
            except Exception:
                context = {}
            bill = _cached_bill_for_reading(context, row)
            reading_day = _normalize_iso_date(row.get("reading_date"))
            if not bill:
                self.alertRequested.emit("Bill Unavailable", "No saved bill calculation is available for this reading.")
                return
            receipt = build_receipt_text(
                apply_authoritative_bill({**row, **context}, bill),
                previous, present, row.get("exception") or "None", self._reader_name,
                reading_date=reading_day,
            )
            latest_entry = {
                "consumer_id": consumer_id,
                "reading_id": None,
                "reading_date": row.get("reading_date"),
                "acct_no": row.get("acct_no"),
                "consumer_name": row.get("name"),
                "meter_no": row.get("meter_no"),
                "zone_name": row.get("zone_name", self._selected_zone),
                "previous_reading": previous,
                "present_reading": present,
                "consumption": consumption,
                "exception": row.get("exception") or "None",
                "reader_name": self._reader_name,
                "receipt_text": receipt,
            }
        if not _receipt_billing_reference(receipt):
            self.alertRequested.emit("Billing Reference Unavailable", "Sync this reading before printing its receipt.")
            return
        if can_use_system_printer():
            try:
                send_to_system_printer(receipt)
            except Exception as exc:
                self.alertRequested.emit("Printer Error", f"Unable to print to the GP58 over USB.\n\n{exc}")
        saved_id = save_receipt_print(
            latest_entry["consumer_id"],
            latest_entry["receipt_text"],
            _to_float(latest_entry["previous_reading"]),
            _to_float(latest_entry["present_reading"]),
            _to_float(latest_entry["consumption"]),
            latest_entry.get("exception") or "None",
            latest_entry.get("reader_name") or self._reader_name,
            latest_entry.get("reading_id"),
            "reprint",
            latest_entry.get("acct_no"),
            latest_entry.get("consumer_name"),
            latest_entry.get("meter_no"),
            latest_entry.get("zone_name"),
        )
        self._last_receipt_entry = {**latest_entry, "id": saved_id, "print_action": "reprint"}
        self._last_receipt = latest_entry["receipt_text"]
        self.canReprintChanged.emit()
        self.receiptPreviewRequested.emit("Receipt Preview", receipt)

    @Slot(int)
    @Slot(int, str)
    def startNewBillForZoneConsumer(self, consumer_id: int, schedule_id: str = "") -> None:
        rows = self._selected_route_consumer_rows()
        row = next((
            item for item in rows
            if int(item.get("id", -1)) == consumer_id
            and (not schedule_id or str(item.get("schedule_id")) == str(schedule_id))
        ), None)
        if not row:
            self.alertRequested.emit("Consumer Not Found", "Unable to load this consumer for a new bill.")
            return

        consumer = get_consumer_by_id(
            consumer_id,
            schedule_date=self.selectedBillingDate,
            meter_reader_id=self._meter_reader_account_id or None,
            schedule_id=row.get("schedule_id"),
        )
        if consumer is None:
            self.alertRequested.emit("Consumer Not Found", "Unable to load this consumer for a new bill.")
            return

        consumer["schedule_id"] = row.get("schedule_id")
        consumer["zone_name"] = row.get("zone_name") or consumer.get("zone_name")

        self._search_query = str(consumer.get("meter_no") or consumer.get("acct_no") or consumer_id)
        self._selected_search_schedule_id = str(row.get("schedule_id") or "")
        self.searchQueryChanged.emit()
        self._refresh_search_suggestions()
        self._load_consumer_for_new_bill(consumer)

    @Slot()
    def logout(self) -> None:
        self.logoutRequested.emit()

    def calculate_consumption(self) -> None:
        if not self._consumer or not self._present_reading:
            self._consumption = "-"
            self._validation_color = "#94a3b8"
            self._validation_message = "-"
            self.consumptionChanged.emit()
            self.validationColorChanged.emit()
            self.validationMessageChanged.emit()
            return

        try:
            present = _to_float(self._present_reading)
            previous = _to_float(self._consumer["previous_reading"])
            diff = present - previous
            
            if diff < 0:
                self._consumption = _format_reading(diff)
                self._validation_color = "#EF4444"
                self._validation_message = "Invalid: Lower than previous"
            elif diff > 500:
                self._consumption = _format_reading(diff)
                self._validation_color = "#F59E0B"
                self._validation_message = "Warning: High Consumption"
            else:
                self._consumption = _format_reading(diff)
                self._validation_color = "#10B981"
                self._validation_message = "Valid"
        except Exception:
            self._consumption = "-"
            self._validation_color = "#EF4444"
            self._validation_message = "Numeric error"

        self.consumptionChanged.emit()
        self.validationColorChanged.emit()
        self.validationMessageChanged.emit()

    @Slot()
    def saveReading(self) -> None:
        self.printReceipt()

    def _set_print_preview_busy(self, busy: bool) -> None:
        if self._print_preview_busy != busy:
            self._print_preview_busy = busy
            self.printPreviewBusyChanged.emit()

    def _open_print_preview(self, title: str, receipt_text: str, action_label: str, job: dict) -> None:
        self._pending_print_job = dict(job)
        self.printPreviewRequested.emit(title, receipt_text, action_label)

    def _build_pending_receipt_job(self) -> dict:
        if self._selected_exception != 'None':
            raise RuntimeError('An unreadable meter must be saved as an issue before any billing.')
        self._reload_current_consumer_from_db()
        self._ensure_current_consumer_receipt_context(force_refresh=True)
        present = _to_float(self._present_reading)
        previous = _to_float(self._consumer["previous_reading"])
        consumption = present - previous
        exception = self._selected_exception
        route = self._selected_route()
        schedule = self._schedule_for_consumer(self._consumer)
        reading_date = manila_current_date().isoformat()
        captured_at = datetime.now().astimezone().isoformat()
        schedule_id = int(schedule.get("scheduleId")) if schedule.get("scheduleId") else None
        if schedule_id is None:
            raise RuntimeError("This consumer's assigned schedule is unavailable. Sync assignments before billing.")
        schedule_date = str(schedule.get("startDate") or route.get("startDate") or self.selectedBillingDate)
        schedule_due_date = str(schedule.get("dueDate") or route.get("dueDate") or schedule_date)
        schedule_payment_due_date = self._default_due_date_for_consumer(self._consumer, reading_date)
        if not schedule_date <= reading_date <= schedule_due_date:
            raise RuntimeError("This reading schedule is not active today. Sync and select a current schedule.")
        billing_cycle = str(schedule.get("billingMonth") or route.get("billingMonth") or schedule_date[:7])
        if not self._sync_dal:
            raise RuntimeError("The local billing-reference store is unavailable.")
        reservation = self._sync_dal.prepareBillingReference(
            self._consumer["id"],
            reading_date,
            schedule_id=schedule_id,
            billing_cycle=billing_cycle,
            allow_unreserved_offline=True,
        )
        sync_reading_id = str(reservation.get("reading_sync_id") or "")
        bill_sync_id = str(reservation.get("bill_sync_id") or "")
        billing_reference = str(reservation.get("billing_reference") or "").strip()
        bill_date = str(reservation.get("bill_date") or reading_date)
        if bill_date != reading_date:
            raise RuntimeError("The reserved bill date does not match the current reading date.")
        reading_route_id = self._consumer.get("reading_route_id")
        assignment_order = self._consumer.get("assignment_order")
        consumer_snapshot = dict(self._consumer)
        assigned_coverage = (consumer_snapshot.get('reading_coverage_by_schedule') or {}).get(str(schedule_id))
        if isinstance(assigned_coverage, dict):
            consumer_snapshot.update(assigned_coverage)
        # A completed offline reading can precede another downloaded cycle.
        # Keep its frozen schedule boundary, even before the next online sync.
        local_history = list(consumer_snapshot.get('local_bills') or [])
        if isinstance(consumer_snapshot.get('local_bill'), dict):
            local_history.append(consumer_snapshot['local_bill'])
        for saved_bill in sorted(local_history, key=lambda item: str(item.get('date_covered_to') or '')):
            boundary = _normalize_iso_date(saved_bill.get('date_covered_to'))
            start = consumer_snapshot.get('coverage_from') or ''
            if (saved_bill.get('meter_no') and saved_bill['meter_no'] == consumer_snapshot.get('meter_no')
                    and saved_bill.get('date_covered_from') and boundary
                    and start < boundary < schedule_date and saved_bill.get('current_reading') is not None):
                consumer_snapshot.update(coverage_from=boundary, previous_schedule_date=boundary,
                                         previous_reading=saved_bill['current_reading'], baseline_required=False)
        if consumer_snapshot.get('previous_reading') is not None:
            previous = _to_float(consumer_snapshot['previous_reading'])
            consumption = present - previous
        if consumption < 0:
            raise RuntimeError('The present reading is lower than the verified previous reading. Review this account before billing.')
        consumer_snapshot["previous_reading_date"] = previous_reading_date(self._consumer)
        consumer_snapshot["billing_reference"] = billing_reference
        consumer_snapshot["schedule_date"] = schedule_date
        consumer_snapshot["schedule_due_date"] = schedule_due_date
        consumer_snapshot["schedule_payment_due_date"] = schedule_payment_due_date
        flagged = False
        required_tariff = ("minimum_cubic", "minimum_rate", "excess_rate_per_cubic")
        missing_tariff = [key for key in required_tariff if consumer_snapshot.get(key) in (None, "")]
        if missing_tariff:
            raise RuntimeError(
                "This consumer's billing rates are not cached. Sync while online before reading offline: "
                + ", ".join(missing_tariff)
            )
        local_bill = _build_bill_payload(
            {
                "consumer_id": self._consumer["id"], "reading_id": sync_reading_id,
                "bill_sync_id": bill_sync_id, "bill_date": bill_date,
                "reading_date": reading_date,
                "schedule_date": schedule_date,
                "coverage_from": consumer_snapshot.get('coverage_from'),
                "coverage_to": schedule_date,
                "previous_reading_date": consumer_snapshot["previous_reading_date"],
                "previous_reading": previous, "present_reading": present,
                "consumption": consumption,
                "schedule_payment_due_date": schedule_payment_due_date,
            },
            consumer_snapshot, 0,
        )
        local_bill.update({
            "sync_id": bill_sync_id or sync_reading_id,
            "billing_reference": billing_reference,
            "schedule_id": schedule_id,
            "meter_no": consumer_snapshot.get('meter_no'),
            "current_reading": present,
        })
        receipt = build_receipt_text(
            apply_authoritative_bill(consumer_snapshot, local_bill),
            previous, present, exception, self._reader_name,
            reading_date=reading_date,
        ) if billing_reference and _has_valid_bill_coverage(local_bill) else (
            f"Account: {consumer_snapshot.get('acct_no') or consumer_snapshot.get('name') or self._consumer['id']}\n"
            f"Reading date: {reading_date}\nPrevious: {_format_reading(previous)}\n"
            f"Present: {_format_reading(present)}\nUse: {_format_reading(consumption)} m3\n\n"
            "A billing reference and verified reading coverage are required before printing.\n\n"
            "Save the reading on this device, then connect and tap Sync Now "
            "before printing its receipt."
        )
        return {
            "job_type": "original",
            "consumer_snapshot": consumer_snapshot,
            "consumer_id": self._consumer["id"],
            "reading_id": None,
            "saved_locally": False,
            "previous": previous,
            "present": present,
            "consumption": consumption,
            "exception": exception,
            "reading_date": reading_date,
            "previous_reading_date": consumer_snapshot["previous_reading_date"],
            "coverage_snapshot": {key: consumer_snapshot.get(key) for key in ('coverage_policy_version','coverage_from','previous_schedule_date','previous_reading','baseline_required')},
            "bill_date": bill_date,
            "due_date": None,
            "schedule_id": schedule_id,
            "schedule_date": schedule_date,
            "schedule_due_date": schedule_due_date,
            "schedule_payment_due_date": schedule_payment_due_date,
            "billing_cycle": billing_cycle,
            "reading_route_id": reading_route_id,
            "assignment_order": assignment_order,
            "sync_reading_id": sync_reading_id,
            "bill_sync_id": bill_sync_id,
            "billing_reference": billing_reference,
            "captured_at": captured_at,
            "authoritative_bill": None,
            "local_bill": local_bill,
            "receipt_text": receipt,
            "reader_name": self._reader_name,
        }

    @Slot()
    def saveMeterIssue(self) -> None:
        if self._operation_busy:
            return
        if not self._consumer or self._selected_exception == 'None' or not self._sync_dal:
            self.alertRequested.emit('Meter issue','Select a consumer and the reason the meter cannot be read.')
            return
        schedule = self._schedule_for_consumer(self._consumer)
        today = manila_current_date().isoformat()
        if not schedule.get('scheduleId') or not str(schedule.get('startDate') or '') <= today <= str(schedule.get('dueDate') or ''):
            self.alertRequested.emit('Schedule unavailable','Select a current reading assignment before reporting a meter issue.')
            return
        payload = {'record_type':'meter_issue','is_flagged':True,'reading_id':str(uuid.uuid4()),
                   'consumer_id':self._consumer['id'],'meter_no':self._consumer.get('meter_no'),
                   'meter_reader_id':self._meter_reader_account_id,'exception':self._selected_exception,
                   'issue_reason':self._selected_exception,'reading_date':today,
                   'captured_at':datetime.now().astimezone().isoformat(),
                   'schedule_id':int(schedule['scheduleId']),'schedule_date':schedule.get('startDate'),
                   'schedule_due_date':schedule.get('dueDate'),'billing_cycle':schedule.get('billingMonth')}
        self._set_operation_busy(True,'Saving meter issue...')
        def task():
            try:
                result = self._sync_dal.saveMeterReading(payload)
                self.meterIssueSaveFinished.emit({'success':True,'synced':result.get('status')=='synced'})
            except Exception as exc:
                self.meterIssueSaveFinished.emit({'success':False,'error':str(exc)})
        threading.Thread(target=task,daemon=True).start()

    def _finish_meter_issue_save(self, result: dict) -> None:
        self._set_operation_busy(False,'')
        self._refresh_sync_snapshot()
        if not result.get('success'):
            self.alertRequested.emit('Meter issue not saved',result.get('error') or 'Try saving the issue again.')
            return
        self.update_stats()
        self._refresh_zone_consumers()
        self.alertRequested.emit('Meter issue saved',
            ('The issue was synced to the office. ' if result.get('synced') else 'The issue is saved on this device and waiting to sync. ')
            + 'Take an actual reading after repair before billing.')

    @Slot()
    def printReceipt(self) -> None:
        if self._selected_exception != 'None':
            self.saveMeterIssue()
            return
        if self._operation_busy:
            return
        if not self._consumer or not self._present_reading:
            self.alertRequested.emit("Missing Details", "Select a consumer and enter a present reading.")
            return

        try:
            self._reload_current_consumer_from_db()
            present = _to_float(self._present_reading)
            previous = _to_float(self._consumer["previous_reading"])
            if present < previous:
                self.alertRequested.emit("Invalid Reading", "Present reading cannot be lower than the previous reading.")
                return
            if self._paper_status.lower() in {"out", "jam"}:
                self.alertRequested.emit("Paper Error", f"Cannot print while paper status is {self._paper_status}.")
                return
        except Exception as e:
            self.alertRequested.emit("Save Failed", str(e))
            return

        self._set_operation_busy(True, "Preparing bill...")

        def _task() -> None:
            try:
                job = self._build_pending_receipt_job()
                self.printPreparationFinished.emit({"success": True, "job": job})
            except Exception as exc:
                self.printPreparationFinished.emit({"success": False, "error": str(exc)})

        threading.Thread(target=_task, daemon=True).start()

    def _finish_print_preparation(self, result: dict) -> None:
        self._set_operation_busy(False, "")
        self._refresh_sync_snapshot()
        if not result.get("success"):
            self.alertRequested.emit("Save Failed", str(result.get("error") or "Unable to prepare the bill."))
            return
        job = result.get("job")
        if not isinstance(job, dict):
            self.alertRequested.emit("Save Failed", "The prepared bill response was invalid.")
            return
        title = "Receipt Preview" if job.get("billing_reference") else "Save Reading"
        self._open_print_preview(title, job["receipt_text"], "Save Reading", job)
        self.update_stats()
        self._refresh_search_suggestions()
        self._refresh_zone_consumers()

    def _refresh_saved_receipt_penalty(self, entry: dict) -> str:
        """Refresh the latest printed bill from the backend without local penalty math."""
        original = str(entry.get("receipt_text") or "")
        if not self._sync_dal or not entry.get("consumer_id"):
            return original
        reference = next(
            (line.split(":", 1)[1].strip() for line in original.splitlines()
             if line.strip().startswith("Billing Ref") and ":" in line),
            "",
        )
        try:
            context = _display_consumer_context(self._sync_dal, int(entry["consumer_id"]))
        except Exception:
            return original
        if not context or str(context.get("billing_reference") or "").strip() != reference:
            return original
        bill = context.get("bill") if isinstance(context.get("bill"), dict) else context
        if not _has_valid_bill_coverage(bill):
            return original
        original_total = next(
            (_to_float(line.rsplit("PHP", 1)[-1].strip()) for line in original.splitlines()
             if line.strip().startswith("TOTAL DUE") and "PHP" in line),
            0.0,
        )
        if (original_total > 0 and _to_float(bill.get("amount_due")) <= 0
                and str(bill.get("status") or bill.get("bill_status") or "").lower() != "paid"):
            return original
        snapshot = apply_authoritative_bill({**context, **entry}, bill)
        reading_date = next(
            (line.split(":", 1)[1].strip() for line in original.splitlines()
             if line.strip().startswith(("Reading Date", "Date")) and ":" in line),
            None,
        )
        try:
            refreshed = build_receipt_text(
                snapshot, _to_float(entry.get("previous_reading")),
                _to_float(entry.get("present_reading")), entry.get("exception") or "None",
                entry.get("reader_name") or self._reader_name,
                reading_date=reading_date,
            )
            return refreshed if _receipt_billing_reference(refreshed) == reference else original
        except (TypeError, ValueError):
            return original

    @Slot(int)
    def setBatteryLevel(self, level: int) -> None:
        self._battery_level = max(0, min(100, level))
        self.batteryLevelChanged.emit()

    @Slot(str)
    def setPaperStatus(self, status: str) -> None:
        normalized = (status or "OK").strip() or "OK"
        self._paper_status = normalized
        self.paperStatusChanged.emit()

    @Slot()
    def reprintLastReceipt(self) -> None:
        if not self._last_receipt_entry:
            self._last_receipt_entry = get_latest_receipt_print()
            self._last_receipt = self._last_receipt_entry["receipt_text"] if self._last_receipt_entry else None
        if not self._last_receipt_entry:
            self.alertRequested.emit("No Receipt", "No saved receipt is available for reprint.")
            return
        if self._paper_status.lower() in {"out", "jam"}:
            self.alertRequested.emit("Paper Error", f"Cannot print while paper status is {self._paper_status}.")
            return
        original_printed_at = str(self._last_receipt_entry.get("printed_at") or "")
        refreshed_receipt = self._refresh_saved_receipt_penalty(self._last_receipt_entry)
        if not _receipt_billing_reference(refreshed_receipt):
            self.alertRequested.emit(
                "Billing Reference Unavailable",
                "Sync this reading, then open its receipt from the consumer list to print it with its billing reference.",
            )
            return
        source_entry = {**self._last_receipt_entry, "receipt_text": refreshed_receipt}
        preview_text = build_reprint_receipt_text(
            refreshed_receipt,
            original_printed_at=original_printed_at,
        )
        job = {
            "job_type": "reprint",
            "source_entry": source_entry,
            "receipt_text": preview_text,
        }
        self._open_print_preview("Reprint Preview", preview_text, "Proceed to Reprint", job)

    @Slot(str)
    def _show_sync_progress(self, message: str) -> None:
        if self._operation_busy:
            self._set_operation_busy(True, message)

    @Slot()
    def syncNow(self) -> None:
        if not self._sync_dal:
            self.alertRequested.emit("Sync Unavailable", self._sync_logs)
            return
        if self._operation_busy:
            self.alertRequested.emit("Sync In Progress", "Please wait for the current operation to finish.")
            return
        if getattr(self, "_assigned_dataset_refreshing", False):
            self.alertRequested.emit("Sync In Progress", "Assigned routes are already downloading. Wait for that download to finish, then retry Sync Now.")
            return
        self._set_operation_busy(True, "Syncing...")
        progress_signal = getattr(self, "syncProgress", None)
        report_progress = progress_signal.emit if progress_signal else lambda _message: None

        def _task() -> None:
            stage = "Starting sync"
            try:
                with self._sync_dal.operation_lock:
                    stage = "Uploading queued readings"
                    report_progress(stage)
                    result = self._sync_dal.syncPendingReadings()
                    pulled = 0
                    mirrored = 0
                    mirror_report: dict = {}
                    try:
                        stage = "Downloading assigned schedules and consumers"
                        date_from, date_to = _assignment_download_window()
                        report_progress(stage)
                        consumers = self._sync_dal.loadAssignedConsumers(
                            self._meter_reader_account_id or None,
                            None,
                            date_from,
                            date_to,
                            require_online=True,
                            progress=report_progress,
                        )
                        self._mirror_assigned_schedules(date_from, date_to)
                        pulled = len(consumers)
                        reservation_result = getattr(self._sync_dal, "last_pre_reservation_result", {}) or {}
                        result = {
                            **result,
                            "offline_references_ready": int(reservation_result.get("ready", 0)),
                            "offline_reference_failures": int(reservation_result.get("failed", 0)),
                        }
                        stage = "Updating the device consumer cache"
                        report_progress(stage)
                        mirrored, mirror_report = _mirror_assigned_consumer_rows(self._sync_dal, consumers)
                        result = {**result, "skipped_records": mirror_report["skipped"]}
                    except Exception as pull_exc:
                        self._sync_dal._audit(None, "failed", format_sync_error(stage, pull_exc, self._backend_endpoint))
                        result = {
                            **result,
                            "pull_error": format_sync_error(stage, pull_exc, self._backend_endpoint),
                        }
                context_pull = self._sync_dal.prefetchAssignedConsumerContexts(consumers, progress=report_progress) if pulled else {}
                self.syncTaskFinished.emit({
                    "kind": "sync", "result": result, "pulled": pulled,
                    "mirrored": mirrored, "context_pull": context_pull,
                    "download_summary": _summarize_assignment_download(consumers, mirror_report) if pulled else "",
                })
            except Exception as exc:
                self.syncTaskFinished.emit(
                    {"kind": "error", "error": format_sync_error(stage, exc, self._backend_endpoint)}
                )

        threading.Thread(target=_task, daemon=True).start()

    @Slot()
    def printTestReceipt(self) -> None:
        if self._test_print_busy:
            return

        self._test_print_busy = True
        self.testPrintBusyChanged.emit()

        def _task() -> None:
            try:
                preview_text = print_test_receipt()
                self.testPrintFinished.emit(True, preview_text)
            except Exception as exc:
                self.testPrintFinished.emit(False, str(exc) or "Unknown printer error.")

        threading.Thread(target=_task, daemon=True).start()

    def _finish_test_print(self, success: bool, payload: str) -> None:
        self._test_print_busy = False
        self.testPrintBusyChanged.emit()
        if success:
            self.alertRequested.emit("Printer Test", "Test print sent successfully.")
            self.receiptPreviewRequested.emit("Test Print Preview", payload)
            return

        detail = payload.strip()
        friendly = "Unable to print. Please check that the thermal printer is connected and powered on."
        if detail:
            friendly = f"{friendly}\n\nDetails: {detail}"
        self.alertRequested.emit("Printer Error", friendly)

    @Slot()
    def cancelPrintPreview(self) -> None:
        self._pending_print_job = None
        self._set_print_preview_busy(False)

    @Slot()
    def proceedPrintPreview(self) -> None:
        if self._print_preview_busy or not self._pending_print_job:
            return

        job = dict(self._pending_print_job)

        if job.get("job_type") == "reprint" and not can_use_system_printer():
            self.alertRequested.emit(
                "Printer Error",
                "Unable to print. Please check that the thermal printer is connected, powered on, and ready.",
            )
            return

        self._set_print_preview_busy(True)
        self._set_operation_busy(True, "Saving reading...")

        def _task() -> None:
            try:
                receipt_text = job["receipt_text"]

                if job.get("job_type") == "original":
                    consumer = dict(job["consumer_snapshot"])
                    present = _to_float(job["present"])
                    previous = _to_float(job["previous"])
                    consumption = _to_float(job["consumption"])
                    exception = str(job["exception"])
                    reading_date = str(job.get("reading_date") or datetime.now().date().isoformat())
                    due_date = None
                    locally_calculated = False
                    local_bill = dict(job.get("local_bill") or {})
                    local_bill_cache_error = None
                    reading_id = int(job.get("reading_id") or 0)
                    if not reading_id:
                        if exception != 'None':
                            raise RuntimeError('An unreadable meter cannot create a bill. Save its issue report instead.')
                        flagged = False
                        reading_id = save_reading(
                            job["consumer_id"], present, consumption, exception, flagged, reading_date,
                            schedule_id=job.get("schedule_id"), schedule_date=job.get("schedule_date"),
                            schedule_due_date=job.get("schedule_due_date"), billing_cycle=job.get("billing_cycle"),
                            reading_route_id=job.get("reading_route_id"), assignment_order=job.get("assignment_order"),
                            reading_status="valid", reading_sync_status="pending",
                            sync_reading_id=job.get("sync_reading_id"), captured_at=job.get("captured_at"),
                        )
                        cache_local_bill = getattr(self._sync_dal, "cacheLocalBill", None)
                        if cache_local_bill and local_bill.get("sync_id") and local_bill.get("billing_reference"):
                            try:
                                cache_local_bill(int(job["consumer_id"]), local_bill)
                            except Exception as exc:
                                local_bill_cache_error = str(exc)
                        sync_result = self._save_to_sync_layer(
                            job["consumer_id"], present, consumption, exception, flagged, reading_date, due_date,
                            sync_reading_id=job.get("sync_reading_id"), captured_at=job.get("captured_at"),
                            schedule_id=job.get("schedule_id"), schedule_date=job.get("schedule_date"),
                            schedule_due_date=job.get("schedule_due_date"), billing_cycle=job.get("billing_cycle"),
                            reading_route_id=job.get("reading_route_id"), assignment_order=job.get("assignment_order"),
                            bill_sync_id=job.get("bill_sync_id"), bill_date=job.get("bill_date"),
                            billing_reference=job.get("billing_reference"),
                            previous_reading_date_snapshot=job.get("previous_reading_date"),
                            coverage_snapshot=job.get('coverage_snapshot'),
                            wait_for_result=True,
                        )
                        if not sync_result:
                            raise RuntimeError("The bill could not be persisted to the local retry queue.")
                        if sync_result.get("status") == "needs_review":
                            self.printExecutionFinished.emit({
                                "success": True, "job_type": "original", "pending_review": True,
                                "consumer_snapshot": consumer, "reading_id": reading_id, "present": present,
                            })
                            return
                        if sync_result.get("status") == "conflict":
                            errors = sync_result.get("errors") or []
                            detail = str(errors[0]) if errors else "The reserved reference conflicts with the bill."
                            raise RuntimeError(f"The backend rejected the bill. {detail}")
                        authoritative_bill = _authoritative_bill_from_sync_result(sync_result) or {}
                        synced_reading = sync_result.get("reading") or {}
                        reference = str(
                            authoritative_bill.get("billing_reference")
                            or synced_reading.get("billing_reference")
                            or job.get("billing_reference") or ""
                        ).strip()
                        if not reference:
                            self.printExecutionFinished.emit({
                                "success": True, "job_type": "original", "pending_reference": True,
                                "consumer_snapshot": consumer, "reading_id": reading_id,
                                "present": present,
                            })
                            return
                        if (not re.fullmatch(r"SLR[0-9]{10}", reference)
                                or reference[3:7] != reading_date[:4]
                                or (job.get("billing_reference") and reference != job["billing_reference"])):
                            raise RuntimeError("The bill's billing reference does not match the prepared receipt.")
                        locally_calculated = _use_local_bill_for_display(authoritative_bill, local_bill)
                        bill_for_receipt = local_bill if locally_calculated else authoritative_bill
                        # Check the same bill that will be rendered. A complete local
                        # interval cannot make an incomplete server bill printable.
                        if not _has_valid_bill_coverage(bill_for_receipt):
                            self.printExecutionFinished.emit({
                                'success': True, 'job_type': 'original', 'pending_review': True, 'review_reason': 'coverage',
                                'consumer_snapshot': consumer, 'reading_id': reading_id, 'present': present,
                            })
                            return
                        consumer["billing_reference"] = reference
                        local_bill["billing_reference"] = reference
                        if cache_local_bill and not job.get("billing_reference"):
                            try:
                                cache_local_bill(int(job["consumer_id"]), local_bill)
                            except Exception as exc:
                                local_bill_cache_error = str(exc)
                        try:
                            fresh_context = _display_consumer_context(self._sync_dal, int(job["consumer_id"]))
                        except Exception:
                            fresh_context = {}
                        consumer = apply_authoritative_bill(
                            {**consumer, **fresh_context},
                            bill_for_receipt,
                        )
                        due_date = _normalize_iso_date(consumer.get("due_date"))
                        receipt_text = build_receipt_text(
                            consumer, previous, present, exception,
                            job.get("reader_name") or self._reader_name,
                            reading_date=reading_date,
                        )
                    saved_receipt_id = None
                    history_error = None
                    if not _receipt_billing_reference(receipt_text):
                        raise RuntimeError("A billing reference is required before this receipt can be printed.")
                    if (job.get("billing_reference")
                            and _receipt_billing_reference(receipt_text) != job["billing_reference"]):
                        raise RuntimeError("The receipt's billing reference changed after the reading was saved.")
                    try:
                        saved_receipt_id = save_receipt_print(
                            job["consumer_id"],
                            receipt_text,
                            previous,
                            present,
                            consumption,
                            exception,
                            job.get("reader_name") or self._reader_name,
                            reading_id,
                            "print",
                            consumer.get("acct_no"),
                            consumer.get("name"),
                            consumer.get("meter_no"),
                            consumer.get("zone_name", self._selected_zone),
                        )
                    except Exception as exc:
                        history_error = str(exc)
                    print_error = None
                    if can_use_system_printer():
                        try:
                            send_to_system_printer(receipt_text)
                        except Exception as exc:
                            print_error = str(exc)
                    else:
                        print_error = "Printer device is unavailable."
                    self.printExecutionFinished.emit(
                        {
                            "success": True,
                            "job_type": "original",
                            "printed": print_error is None,
                            "print_error": print_error,
                            "saved_receipt_id": saved_receipt_id,
                            "history_error": history_error,
                            "reading_id": reading_id,
                            "consumer_snapshot": consumer,
                            "previous": previous,
                            "present": present,
                            "consumption": consumption,
                            "exception": exception,
                            "due_date": due_date,
                            "receipt_text": receipt_text,
                            "locally_calculated": locally_calculated,
                            "local_bill_cache_error": local_bill_cache_error,
                            "synced": sync_result.get("status") == "synced",
                        }
                    )
                    return

                source_entry = dict(job["source_entry"])
                refreshed_source = self._refresh_saved_receipt_penalty(source_entry)
                receipt_text = build_reprint_receipt_text(
                    refreshed_source,
                    original_printed_at=str(source_entry.get("printed_at") or ""),
                )
                if not _receipt_billing_reference(receipt_text):
                    raise RuntimeError("Sync this reading before printing its receipt with a billing reference.")
                send_to_system_printer(receipt_text)
                saved_id = None
                history_error = None
                try:
                    saved_id = save_receipt_print(
                        source_entry["consumer_id"],
                        receipt_text,
                        _to_float(source_entry["previous_reading"]),
                        _to_float(source_entry["present_reading"]),
                        _to_float(source_entry["consumption"]),
                        source_entry.get("exception") or "None",
                        self._reader_name,
                        source_entry.get("reading_id"),
                        "reprint",
                        source_entry.get("acct_no"),
                        source_entry.get("consumer_name"),
                        source_entry.get("meter_no"),
                        source_entry.get("zone_name"),
                    )
                except Exception as exc:
                    history_error = str(exc)
                self.printExecutionFinished.emit(
                    {
                        "success": True,
                        "job_type": "reprint",
                        "saved_receipt_id": saved_id,
                        "history_error": history_error,
                        "source_entry": source_entry,
                        "receipt_text": receipt_text,
                    }
                )
            except Exception as exc:
                self.printExecutionFinished.emit({"success": False, "error": str(exc)})

        threading.Thread(target=_task, daemon=True).start()

    def _finish_print_execution(self, result: dict) -> None:
        self._set_print_preview_busy(False)
        self._set_operation_busy(False, "")
        if not result.get("success"):
            self.alertRequested.emit(
                "Printer Error",
                "Unable to print. Please check that the thermal printer is connected, powered on, and ready."
                + (f"\n\nDetails: {result.get('error')}" if result.get("error") else ""),
            )
            return

        self._pending_print_job = None
        if result.get("job_type") == "original":
            consumer = dict(result["consumer_snapshot"])
            present = _to_float(result["present"])
            if result.get("pending_reference") or result.get("pending_review"):
                needs_review = bool(result.get("pending_review"))
                coverage_review = result.get("review_reason") == "coverage"
                self._consumer["previous_reading"] = present
                self._previous_reading = _format_reading(present)
                self._present_reading = ""
                self._consumption = "-"
                self._validation_message = (
                    "Saved; reading coverage needs review" if coverage_review else
                    "Saved; assignment needs review" if needs_review else "Saved; billing reference pending sync"
                )
                self.previousReadingChanged.emit()
                self.presentReadingChanged.emit()
                self.consumptionChanged.emit()
                self.validationMessageChanged.emit()
                self._refresh_local_assignment_views()
                self.alertRequested.emit(
                    "Reading Saved for Review" if needs_review else "Reading Saved",
                    "Reading saved on this device. Ask the Billing Officer to verify this account's opening "
                    "reading and coverage in Bills Registry, then connect and tap Sync Now before printing."
                    if coverage_review else
                    "This reading's schedule is cancelled. Its reading and billing reference are saved "
                    "for assignment review. Other readings can continue syncing."
                    if needs_review else
                    "Reading saved on this device. Connect and tap Sync Now before printing "
                    "the receipt with its exact billing reference.",
                )
                return
            if result.get("pending_calculation"):
                self._consumer["previous_reading"] = present
                self._previous_reading = _format_reading(present)
                self._present_reading = ""
                self._due_date = str(result.get("schedule_payment_due_date") or "")
                self._due_date_confirmed = False
                self._validation_message = "Pending server calculation"
                self.previousReadingChanged.emit()
                self.presentReadingChanged.emit()
                self.dueDateChanged.emit()
                self.validationMessageChanged.emit()
                self._refresh_local_assignment_views()
                self.alertRequested.emit(
                    "Reading Saved",
                    "Reading saved in SQLite. Bill payment date and penalties are pending server calculation.",
                )
                return
            try:
                latest_receipt = get_latest_receipt_print(consumer["id"])
            except Exception:
                latest_receipt = None
            self._last_receipt_entry = latest_receipt or {
                "id": result["saved_receipt_id"],
                "consumer_id": consumer["id"],
                "reading_id": result["reading_id"],
                "acct_no": consumer.get("acct_no"),
                "consumer_name": consumer.get("name"),
                "meter_no": consumer.get("meter_no"),
                "zone_name": consumer.get("zone_name", self._selected_zone),
                "previous_reading": _to_float(result["previous"]),
                "present_reading": present,
                "consumption": _to_float(result["consumption"]),
                "exception": result.get("exception") or "None",
                "due_date": result.get("due_date") or consumer.get("due_date"),
                "reader_name": self._reader_name,
                "receipt_text": result["receipt_text"],
                "print_action": "print",
            }
            self._last_receipt = result["receipt_text"]
            self.canReprintChanged.emit()
            self._consumer["previous_reading"] = present
            if result.get("due_date"):
                self._consumer["due_date"] = result["due_date"]
                self._due_date = result["due_date"]
                self._due_date_confirmed = not result.get("locally_calculated")
                self.dueDateChanged.emit()
            self._previous_reading = _format_reading(present)
            self._present_reading = ""
            self._consumption = "-"
            self._validation_color = "#10B981"
            self._validation_message = (
                "Saved with local bill amounts; sync will reconcile"
                if result.get("locally_calculated") else "Saved successfully!"
            )
            self.previousReadingChanged.emit()
            self.presentReadingChanged.emit()
            self.consumptionChanged.emit()
            self.validationColorChanged.emit()
            self.validationMessageChanged.emit()
            self._refresh_local_assignment_views()
            self.refreshPrintHistory()
            if result.get("printed", True):
                message = "Receipt printed successfully."
                if result.get("locally_calculated"):
                    message += (
                        "\n\nThe main system returned zero or missing totals. This receipt uses "
                        "device-cached amounts and needs reconciliation."
                        if result.get("synced") else
                        "\n\nAmounts came from the device cache and will be checked on sync."
                    )
                if result.get("history_error"):
                    message += "\n\nThe print-history record could not be saved and will not appear in History."
                if result.get("local_bill_cache_error"):
                    message += "\n\nThe local bill details could not be cached. The saved receipt is still available for reprint."
                self.alertRequested.emit("Print Complete", message)
            else:
                self.alertRequested.emit(
                    "Reading Saved",
                    "Reading saved successfully, but printing failed."
                    + (f"\n\nDetails: {result.get('print_error')}" if result.get("print_error") else ""),
                )
            return

        source_entry = dict(result["source_entry"])
        saved_receipt_id = result.get("saved_receipt_id") or source_entry.get("id")
        self._last_receipt_entry = {**source_entry, "id": saved_receipt_id, "print_action": "reprint", "receipt_text": result["receipt_text"]}
        self._last_receipt = result["receipt_text"]
        self.canReprintChanged.emit()
        self.refreshPrintHistory()
        message = "Receipt reprinted successfully."
        if result.get("history_error"):
            message += "\n\nThe reprint-history record could not be saved and will not appear in History."
        self.alertRequested.emit("Reprint Complete", message)

    @Slot()
    def openPrintHistory(self) -> None:
        self._print_history_months = list_receipt_print_months()
        if self._selected_print_history_month not in self._print_history_months:
            self._selected_print_history_month = ""
        self.printHistoryFiltersChanged.emit()
        self.refreshPrintHistory()
        self.printHistoryRequested.emit()

    @Slot(str)
    def refreshPrintHistory(self, search_text: str = "") -> None:
        self._print_history_search = str(search_text or "")
        months = list_receipt_print_months()
        if months != self._print_history_months:
            self._print_history_months = months
            if self._selected_print_history_month not in months:
                self._selected_print_history_month = ""
            self.printHistoryFiltersChanged.emit()
        rows = list_receipt_print_history(
            search_text=self._print_history_search,
            month=self._selected_print_history_month or None,
            print_action=self._selected_print_history_action or None,
        )
        self._print_history_records = [
            {
                "id": row.get("id"),
                "receipt_number": f"{int(row.get('id', 0)):06d}" if row.get("id") else "",
                "receipt_type": "Receipt",
                "account_number": row.get("acct_no") or "",
                "consumer_name": row.get("consumer_name") or "",
                "billing_period": row.get("zone_name") or "",
                "total_amount": row.get("consumption") or 0,
                "printed_at": row.get("printed_at") or "",
                "printed_by": row.get("reader_name") or "",
                "print_count": row.get("print_count") or 1,
                "reprint_count": row.get("reprint_count") or 0,
                "print_action": row.get("print_action") or "print",
            }
            for row in rows
        ]
        self.printHistoryRecordsChanged.emit()

    @Slot(str)
    def setPrintHistoryMonth(self, month: str) -> None:
        normalized = str(month or "").strip()
        if normalized and normalized not in self._print_history_months:
            return
        if self._selected_print_history_month != normalized:
            self._selected_print_history_month = normalized
            self.printHistoryFiltersChanged.emit()
        self.refreshPrintHistory(self._print_history_search)

    @Slot(str)
    def setPrintHistoryAction(self, print_action: str) -> None:
        normalized = str(print_action or "").strip().lower()
        if normalized not in {"", "print", "reprint"}:
            return
        if self._selected_print_history_action != normalized:
            self._selected_print_history_action = normalized
            self.printHistoryFiltersChanged.emit()
        self.refreshPrintHistory(self._print_history_search)

    @Slot(int)
    def openPrintHistoryDetail(self, receipt_print_id: int) -> None:
        self._print_history_detail = get_receipt_print_by_id(receipt_print_id)
        if self._print_history_detail:
            self._print_history_detail["receipt_text"] = self._refresh_saved_receipt_penalty(
                self._print_history_detail
            )
        self.printHistoryDetailChanged.emit()

    @Slot()
    def closePrintHistoryDetail(self) -> None:
        self._print_history_detail = None
        self.printHistoryDetailChanged.emit()

    @Slot()
    def reprintSelectedHistory(self) -> None:
        if not self._print_history_detail:
            return
        if self._paper_status.lower() in {"out", "jam"}:
            self.alertRequested.emit("Paper Error", f"Cannot print while paper status is {self._paper_status}.")
            return
        refreshed_receipt = self._refresh_saved_receipt_penalty(self._print_history_detail)
        if not _receipt_billing_reference(refreshed_receipt):
            self.alertRequested.emit(
                "Billing Reference Unavailable",
                "Sync this reading, then open its receipt from the consumer list to print it with its billing reference.",
            )
            return
        source_entry = {**self._print_history_detail, "receipt_text": refreshed_receipt}
        preview_text = build_reprint_receipt_text(
            refreshed_receipt,
            original_printed_at=str(self._print_history_detail.get("printed_at") or ""),
        )
        self._open_print_preview(
            "Reprint Preview",
            preview_text,
            "Proceed to Reprint",
            {
                "job_type": "reprint",
                "source_entry": source_entry,
                "receipt_text": preview_text,
            },
        )

    @Slot()
    def powerOffDevice(self) -> None:
        if os.name == "nt":
            self.alertRequested.emit(
                "Windows Preview",
                "Safe power-off is intended for the Raspberry Pi device.\n\n"
                "On the Pi, this button will request a graceful OS shutdown before external power is removed.",
            )
            return

        self._set_operation_busy(True, "Syncing before power off...")

        def _task() -> None:
            try:
                if self._sync_dal:
                    result = self._sync_dal.syncPendingReadings()
                    if result.get("status") != "done":
                        detail = str(result.get("error") or result.get("status") or "Sync failed before shutdown.")
                        self.powerOffFailed.emit(f"Shutdown cancelled because sync did not complete cleanly.\n\n{detail}")
                        return

                    pending_after_sync = len(self._sync_dal.listPendingBackendReadings())
                    if pending_after_sync > 0:
                        self.powerOffFailed.emit(
                            f"Shutdown cancelled because {pending_after_sync} reading(s) are still pending Backend API sync."
                        )
                        return
                    self.syncTaskFinished.emit(
                        {"kind": "sync", "result": result, "mirrored": 0, "silent": True, "keep_busy": True}
                    )
            except Exception as exc:
                self.powerOffFailed.emit(
                    f"Shutdown cancelled because the pre-shutdown sync failed.\n\n{str(exc) or 'Unknown sync error.'}"
                )
                return

            commands = [
                ["sudo", "-n", "systemctl", "poweroff"],
                ["sudo", "-n", "shutdown", "-h", "now"],
                ["sudo", "-n", "poweroff"],
                ["systemctl", "poweroff"],
                ["shutdown", "-h", "now"],
                ["poweroff"],
            ]

            last_error = "Power-off command failed."
            for command in commands:
                try:
                    result = subprocess.run(
                        command,
                        capture_output=True,
                        text=True,
                        timeout=12,
                        check=False,
                    )
                    if result.returncode == 0:
                        return
                    detail = (result.stderr or result.stdout or "").strip()
                    if detail:
                        last_error = _normalize_shutdown_error(detail)
                except FileNotFoundError:
                    continue
                except subprocess.TimeoutExpired:
                    return
                except Exception as exc:
                    last_error = _normalize_shutdown_error(str(exc) or last_error)

            self.powerOffFailed.emit(last_error)

        threading.Thread(target=_task, daemon=True).start()

    def _finish_power_off_failure(self, detail: str) -> None:
        self._set_operation_busy(False, "")
        self.alertRequested.emit(
            "Shutdown Cancelled",
            detail,
        )

    @Slot()
    def update_stats(self) -> None:
        try:
            route_rows = self._selected_route_consumer_rows()
        except Exception:
            route_rows = []
        stats: dict[str, dict] = {}
        for row in route_rows:
            zone_name = str(row.get("zone_name") or "Unassigned")
            zone = stats.setdefault(zone_name, {"households": 0, "read": 0, "flagged": 0})
            zone["households"] += 1
            zone["read"] += 1 if row.get("is_read") else 0
            zone["flagged"] += 1 if row.get("is_flagged") else 0
        if not stats:
            self._overall_percentage = 0
            self._overall_fraction = "0/0"
            self._zone_read_fraction = "0/0"
            self._zone_completion_percentage = 0
            self._zone_flagged_count = 0
            self._zone_remaining_count = 0
            self.overallPercentageChanged.emit()
            self.overallFractionChanged.emit()
            self.zoneReadFractionChanged.emit()
            self.zoneCompletionPercentageChanged.emit()
            self.zoneFlaggedCountChanged.emit()
            self.zoneRemainingCountChanged.emit()
            return

        # Overall completion calculations
        total_read = 0
        total_households = 0
        flagged = 0
        for z_name, z_data in stats.items():
            total_read += z_data["read"]
            total_households += z_data["households"]
            flagged += z_data["flagged"]

        if total_households > 0:
            self._overall_percentage = int((total_read / total_households) * 100)
        else:
            self._overall_percentage = 0

        self._overall_fraction = f"{total_read}/{total_households} read"
        self.overallPercentageChanged.emit()
        self.overallFractionChanged.emit()

        # Active Zone calculations
        active_zone = (
            {"households": total_households, "read": total_read, "flagged": flagged}
            if self._selected_zone == "All zones"
            else stats.get(self._selected_zone)
        )
        if active_zone:
            self._zone_read_fraction = f"{active_zone['read']}/{active_zone['households']}"
            if active_zone['households'] > 0:
                self._zone_completion_percentage = int((active_zone['read'] / active_zone['households']) * 100)
            else:
                self._zone_completion_percentage = 0
            self._zone_flagged_count = active_zone["flagged"]
            self._zone_remaining_count = max(0, active_zone['households'] - active_zone['read'])
        else:
            self._zone_read_fraction = "0/0"
            self._zone_completion_percentage = 0
            self._zone_flagged_count = 0
            self._zone_remaining_count = 0

        self.zoneReadFractionChanged.emit()
        self.zoneCompletionPercentageChanged.emit()
        self.zoneFlaggedCountChanged.emit()
        self.zoneRemainingCountChanged.emit()
        if self._progress_details_visible:
            self._refresh_zone_consumers()


class LoginPage(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.bridge = LoginBridge()
        self.bridge.setParent(self)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.quick = QQuickWidget()
        self.quick.rootContext().setContextProperty("loginBridge", self.bridge)
        _load_qml(self.quick, QML_LOGIN_FILE)
        layout.addWidget(self.quick)


class MainContainerPage(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.bridge = AppBridge()
        self.bridge.setParent(self)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.quick = QQuickWidget()
        self.quick.rootContext().setContextProperty("appBridge", self.bridge)
        _load_qml(self.quick, QML_MAIN_FILE)
        layout.addWidget(self.quick)




class HybridMainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Water Meter Reader")
        self.resize(480, 800)  # Match the portrait touchscreen viewport more closely.

        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)
        self._init_login_page()

    def _init_login_page(self) -> None:
        self.login_page = LoginPage()
        self.main_page = None
        self.stack.addWidget(self.login_page)
        self.login_page.bridge.loginSuccess.connect(self._on_login_success)
        # Let Qt display the login page before database repairs and migrations.
        QTimer.singleShot(0, self.login_page.bridge.prepare_database)

    def _on_login_success(self, user: dict) -> None:
        self.login_page.bridge.set_workspace_loading(True)
        QTimer.singleShot(0, lambda: self._complete_login_success(user))

    def _complete_login_success(self, user: dict) -> None:
        try:
            if self.main_page is None:
                page = MainContainerPage()
                self.stack.addWidget(page)
                page.bridge.logoutRequested.connect(self._on_logout_requested)
                page.bridge.sessionExpired.connect(self._on_session_expired)
                self.main_page = page
            self.main_page.bridge.set_user(user, self.login_page.bridge._sync_dal)
            self.stack.setCurrentWidget(self.main_page)
            self.main_page.bridge.showWelcomeToast()
        except Exception as exc:
            self.stack.setCurrentWidget(self.login_page)
            self.login_page.bridge._finish_login_attempt(False, None, f"Unable to open reading screen: {exc}")
        finally:
            self.login_page.bridge.set_workspace_loading(False)

    def stop_background_work(self) -> None:
        if self.main_page is not None:
            self.main_page.bridge.stop_heartbeat()

    def _on_logout_requested(self) -> None:
        self.main_page.bridge.clear_user()
        login_dal = self.login_page.bridge._sync_dal
        if login_dal:
            login_dal.setAuthenticatedSession(None, None)
        self.login_page.bridge.clearInputsRequested.emit()
        self.stack.setCurrentWidget(self.login_page)

    def _on_session_expired(self) -> None:
        # Expiry stops authenticated online requests, not local field work.
        self.login_page.bridge.show_session_expired()

def run_qt_hybrid() -> int:
    if SyncConfig is None:
        raise RuntimeError("Sync module is unavailable.")
    SyncConfig.from_env(fail_fast=True)
    app = QApplication.instance() or QApplication(sys.argv)
    app.setFont(QFont("Montserrat", 10))
    app.setStyle("Fusion")
    win = HybridMainWindow()
    app.aboutToQuit.connect(win.stop_background_work)
    win.show()
    # Include the title bar and window borders when fitting the touchscreen.
    def fit_window_to_screen():
        available = win.screen().availableGeometry()
        frame = win.frameGeometry()
        border_width = max(0, frame.width() - win.width())
        border_height = max(0, frame.height() - win.height())
        win.resize(
            min(win.width(), max(1, available.width() - border_width)),
            min(win.height(), max(1, available.height() - border_height)),
        )
        frame = win.frameGeometry()
        win.move(
            max(available.left(), min(frame.left(), available.right() - frame.width() + 1)),
            max(available.top(), min(frame.top(), available.bottom() - frame.height() + 1)),
        )

    QTimer.singleShot(0, fit_window_to_screen)
    return app.exec()
